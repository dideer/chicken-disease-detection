<?php
$page_title = 'Wind Land Hotel — Your Room, Intelligently Yours';
$base_path  = '';
include 'includes/header.php';
?>

<!-- ═══ HERO ══════════════════════════════════════════════ -->
<section class="hero" aria-label="Hero">
  <div class="hero__grid-bg" aria-hidden="true"></div>
  <div class="hero__glow" aria-hidden="true"></div>
  <div class="hero__glow-gold" aria-hidden="true"></div>

  <div class="hero__inner">
    <div class="hero__eyebrow" aria-hidden="true">
      <span class="hero__eyebrow-dot"></span>
      <span>Kigali, Rwanda · Est. 2024</span>
    </div>

    <h1>Your room,<br><em>intelligently yours</em></h1>

    <p class="hero__sub">
      Wind Land Hotel blends luxury hospitality with intelligent automation —
      seamless PIN access, real-time room control, and smart comfort that adapts to you.
    </p>

    <div class="hero__actions">
      <a href="pages/guest/rooms.php" class="btn btn--primary btn--lg">Browse Rooms</a>
      <a href="#how-it-works" class="btn btn--outline btn--lg">How it Works</a>
    </div>

    <div class="hero__stats" role="list">
      <div class="hero__stat" role="listitem">
        <span class="hero__stat-value">11</span>
        <span class="hero__stat-label">Smart Rooms</span>
      </div>
      <div class="hero__stat-divider" aria-hidden="true"></div>
      <div class="hero__stat" role="listitem">
        <span class="hero__stat-value">24/7</span>
        <span class="hero__stat-label">Automation</span>
      </div>
      <div class="hero__stat-divider" aria-hidden="true"></div>
      <div class="hero__stat" role="listitem">
        <span class="hero__stat-value">6-Digit</span>
        <span class="hero__stat-label">PIN Access</span>
      </div>
    </div>
  </div>
</section>

<!-- ═══ AVAILABLE ROOMS ════════════════════════════════════ -->
<section class="section" id="rooms" aria-labelledby="rooms-title">
  <div class="container">
    <div class="text-center mb-32">
      <p class="section-label">Available Now</p>
      <h2 id="rooms-title" class="section-title">Curated Smart Rooms</h2>
      <p class="section-subtitle">Each room is equipped with intelligent sensors and automation systems designed for your comfort.</p>
    </div>

    <div class="grid-3">

      <!-- Room 101 -->
      <article class="room-card" data-type="single">
        <div class="room-card__header">
          <div>
            <div class="room-card__number">101</div>
            <div class="room-card__type">Single Room</div>
          </div>
          <div class="room-card__status">
            <span class="status-dot status-dot--available"></span>
            Available
          </div>
        </div>
        <div class="room-card__body">
          <div class="room-card__floor">Floor 1 · Ground Level</div>
          <div class="room-card__price">$89 <span>/ night</span></div>
          <div class="tags">
            <span class="tag tag--forest">Auto Lighting</span>
            <span class="tag tag--forest">Smart AC</span>
            <span class="tag tag--gold">Motion Sensor</span>
          </div>
        </div>
        <div class="room-card__footer">
          <a href="pages/guest/booking.php?room=101" class="btn btn--forest btn--full btn--sm">Book Now</a>
        </div>
      </article>

      <!-- Room 201 -->
      <article class="room-card" data-type="double">
        <div class="room-card__header">
          <div>
            <div class="room-card__number">201</div>
            <div class="room-card__type">Double Room</div>
          </div>
          <div class="room-card__status">
            <span class="status-dot status-dot--available"></span>
            Available
          </div>
        </div>
        <div class="room-card__body">
          <div class="room-card__floor">Floor 2 · City View</div>
          <div class="room-card__price">$145 <span>/ night</span></div>
          <div class="tags">
            <span class="tag tag--forest">Auto Lighting</span>
            <span class="tag tag--forest">Smart AC</span>
            <span class="tag tag--gold">Motion Sensor</span>
            <span class="tag tag--gold">Smart TV</span>
          </div>
        </div>
        <div class="room-card__footer">
          <a href="pages/guest/booking.php?room=201" class="btn btn--forest btn--full btn--sm">Book Now</a>
        </div>
      </article>

      <!-- Room 301 -->
      <article class="room-card" data-type="suite">
        <div class="room-card__header" style="background: linear-gradient(135deg, #1E4530, #0E1612);">
          <div>
            <div class="room-card__number">301</div>
            <div class="room-card__type" style="color:var(--gold-light);">Presidential Suite</div>
          </div>
          <div class="room-card__status">
            <span class="status-dot status-dot--available"></span>
            Available
          </div>
        </div>
        <div class="room-card__body">
          <div class="room-card__floor">Floor 3 · Panoramic View</div>
          <div class="room-card__price">$320 <span>/ night</span></div>
          <div class="tags">
            <span class="tag tag--forest">Auto Lighting</span>
            <span class="tag tag--forest">Smart AC</span>
            <span class="tag tag--gold">Motion Sensor</span>
            <span class="tag tag--gold">Smart TV</span>
            <span class="tag tag--gold">Jacuzzi Control</span>
          </div>
        </div>
        <div class="room-card__footer">
          <a href="pages/guest/booking.php?room=301" class="btn btn--primary btn--full btn--sm">Book Suite</a>
        </div>
      </article>

    </div><!-- /.grid-3 -->

    <div class="text-center mt-32">
      <a href="pages/guest/rooms.php" class="btn btn--outline-dark">View All 11 Rooms</a>
    </div>
  </div>
</section>

<!-- ═══ HOW IT WORKS ═══════════════════════════════════════ -->
<section class="section" id="how-it-works" style="background: var(--paper);" aria-labelledby="hiw-title">
  <div class="container">
    <div class="text-center mb-32">
      <p class="section-label">The Process</p>
      <h2 id="hiw-title" class="section-title">How Wind Land Works</h2>
      <p class="section-subtitle">Four simple steps to a seamlessly intelligent hotel experience.</p>
    </div>

    <div class="steps-grid">
      <article class="step-card">
        <div class="step-card__num">01</div>
        <h4>Book Online</h4>
        <p>Choose your room, pick your dates, and confirm your booking through our secure portal in minutes.</p>
      </article>
      <article class="step-card">
        <div class="step-card__num">02</div>
        <h4>Receive Your PIN</h4>
        <p>A unique 6-digit PIN is generated instantly for your stay. It activates exactly on your check-in date.</p>
      </article>
      <article class="step-card">
        <div class="step-card__num">03</div>
        <h4>Enter Room Number + PIN</h4>
        <p>At the door panel, type your room number first, then your 6-digit PIN. No cards, no keys, no queues.</p>
      </article>
      <article class="step-card">
        <div class="step-card__num">04</div>
        <h4>Automation Starts</h4>
        <p>The moment you step in, the room responds — lighting adjusts, temperature sets itself, and everything is ready.</p>
      </article>
    </div>
  </div>
</section>

<!-- ═══ CALL TO ACTION ═════════════════════════════════════ -->
<section class="section" aria-labelledby="cta-title">
  <div class="container">
    <div class="cta-banner">
      <p class="section-label" style="justify-content:center;">Ready</p>
      <h2 id="cta-title">Ready to experience<br><em style="color:var(--gold-light);font-style:italic;">smart comfort?</em></h2>
      <p>Create an account to start booking. Your intelligent stay awaits.</p>
      <div style="display:flex;gap:14px;justify-content:center;flex-wrap:wrap;">
        <a href="pages/guest/register.php" class="btn btn--primary btn--lg">Create Account</a>
        <a href="pages/guest/login.php"    class="btn btn--outline btn--lg">Login</a>
      </div>
    </div>
  </div>
</section>

<?php include 'includes/footer.php'; ?>
