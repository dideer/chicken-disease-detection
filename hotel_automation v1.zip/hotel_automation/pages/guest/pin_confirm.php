<?php
require_once '../../config/config.php';
require_once '../../config/Database.php';
require_once '../../classes/Booking.php';
require_once '../../classes/Pin.php';
require_once '../../includes/guest_auth.php';

$booking_id = (int)($_GET['booking_id'] ?? 0);
$bookingObj = new Booking();
$booking    = $bookingObj->getById($booking_id);

// Security: booking must exist and belong to this guest
if (!$booking || (int)$booking['guest_id'] !== (int)$_SESSION['guest_id']) {
    header('Location: guest_dashboard.php');
    exit;
}

// Load PIN — need room details too
$pinObj = new Pin();
$pin    = $pinObj->getByBooking($booking_id);

if (!$pin) {
    header('Location: guest_dashboard.php');
    exit;
}

// Get room number
$db = Database::getInstance()->getConnection();
$roomStmt = $db->prepare("SELECT room_number, floor, type FROM rooms WHERE id = ? LIMIT 1");
$roomData = null;
if ($roomStmt) {
    $roomStmt->bind_param('i', $booking['room_id']);
    $roomStmt->execute();
    $roomData = $roomStmt->get_result()->fetch_assoc();
    $roomStmt->close();
}

$page_title = 'Your Door PIN — Wind Land Hotel';
$base_path  = '../../';
include '../../includes/header.php';
?>

<!-- ═══ PAGE HERO ════════════════════════════════════════ -->
<section class="page-hero" aria-labelledby="pin-title">
  <div class="container text-center">
    <p class="page-hero__label">Booking Confirmed</p>
    <h1 id="pin-title">Your Smart Room is Ready</h1>
    <p>Save your PIN — you will need it to enter your room at the door keypad.</p>
  </div>
</section>

<!-- ═══ PIN SECTION ══════════════════════════════════════ -->
<section class="section" aria-label="PIN and booking details">
  <div class="container container--narrow">

    <!-- Success alert -->
    <div class="alert alert--success mb-24" role="alert">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
      Booking confirmed! Room
      <?php if ($roomData): ?>
        <strong><?php echo htmlspecialchars($roomData['room_number']); ?></strong>
      <?php endif; ?>
      is reserved from
      <strong><?php echo date('d M Y', strtotime($booking['check_in'])); ?></strong>
      to
      <strong><?php echo date('d M Y', strtotime($booking['check_out'])); ?></strong>.
    </div>

    <!-- PIN card -->
    <div class="card mb-24">
      <div class="card__body text-center">

        <!-- Room info -->
        <?php if ($roomData): ?>
          <div class="mb-24">
            <span class="room-number-badge" style="font-size:1rem;padding:8px 20px;">
              Room <?php echo htmlspecialchars($roomData['room_number']); ?>
            </span>
            <p class="text-muted mt-8" style="font-size:0.85rem;">
              <?php echo ucfirst(htmlspecialchars($roomData['type'])); ?>
              &middot; Floor <?php echo (int)$roomData['floor']; ?>
            </p>
          </div>
        <?php endif; ?>

        <!-- How to use -->
        <div class="mb-24">
          <p class="section-label" style="justify-content:center;">How to enter your room</p>
          <div class="grid-2" style="gap:12px;text-align:left;">
            <div class="card" style="border-color:var(--forest);padding:0;">
              <div class="card__body">
                <p class="text-muted" style="font-size:0.72rem;font-family:var(--font-mono);letter-spacing:0.1em;text-transform:uppercase;margin-bottom:4px;">Step 1</p>
                <p style="font-size:0.88rem;font-weight:600;color:var(--text-dark);">Enter your room number at the keypad</p>
              </div>
            </div>
            <div class="card" style="border-color:var(--gold);padding:0;">
              <div class="card__body">
                <p class="text-muted" style="font-size:0.72rem;font-family:var(--font-mono);letter-spacing:0.1em;text-transform:uppercase;margin-bottom:4px;">Step 2</p>
                <p style="font-size:0.88rem;font-weight:600;color:var(--text-dark);">Enter your 6-digit PIN below</p>
              </div>
            </div>
          </div>
        </div>

        <!-- PIN digits -->
        <p class="section-label mb-16" style="justify-content:center;">Your 6-Digit Access PIN</p>
        <div class="pin-display" role="group" aria-label="Your 6-digit access PIN">
          <?php foreach (str_split($pin['pin_code']) as $digit): ?>
            <div class="pin-digit"><?php echo htmlspecialchars($digit); ?></div>
          <?php endforeach; ?>
        </div>

        <!-- Expiry -->
        <p class="text-muted mt-16" style="font-size:0.83rem;">
          PIN expires: <strong><?php echo date('d M Y, h:i A', strtotime($pin['expires_at'])); ?></strong>
        </p>

      </div>
    </div>

    <!-- Warning -->
    <div class="alert alert--warning mb-32" role="alert">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0;"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
      <div>
        <strong>Keep this PIN private.</strong> Do not share it with anyone.
        It expires automatically on your checkout date.
      </div>
    </div>

    <!-- Action buttons -->
    <div class="flex gap-16" style="flex-wrap:wrap;justify-content:center;">
      <a href="room_control.php" class="btn btn--forest btn--lg">Go to Room Control</a>
      <a href="guest_dashboard.php" class="btn btn--ghost btn--lg">Back to Dashboard</a>
    </div>

  </div>
</section>

<?php include '../../includes/footer.php'; ?>
