<?php
/**
 * Wind Land Hotel — Guest Checkout
 * Pure PHP handler — no HTML output.
 */

require_once '../../config/config.php';
require_once '../../config/Database.php';
require_once '../../classes/Booking.php';
require_once '../../classes/Pin.php';
require_once '../../includes/guest_auth.php';

$db = Database::getInstance()->getConnection();

// Find this guest's active booking
$activeBooking = null;
$stmt = $db->prepare(
    "SELECT id, room_id FROM bookings
     WHERE guest_id = ? AND status = 'active'
     ORDER BY created_at DESC LIMIT 1"
);
if ($stmt) {
    $gid = (int)$_SESSION['guest_id'];
    $stmt->bind_param('i', $gid);
    $stmt->execute();
    $activeBooking = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

if (!$activeBooking) {
    header('Location: guest_dashboard.php');
    exit;
}

$bookingObj = new Booking();
$pinObj     = new Pin();

$pinObj->expire((int)$activeBooking['id']);
$bookingObj->checkout((int)$activeBooking['id']);

header('Location: guest_dashboard.php?success=checked_out');
exit;
