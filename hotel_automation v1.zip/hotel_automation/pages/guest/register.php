<?php
require_once '../../config/config.php';
require_once '../../config/Database.php';
require_once '../../classes/Guest.php';

if (isset($_SESSION['guest_id'])) {
    header('Location: guest_dashboard.php');
    exit;
}

$errors = [];
$input  = ['full_name'=>'','email'=>'','phone'=>''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $email     = trim($_POST['email']     ?? '');
    $phone     = trim($_POST['phone']     ?? '');
    $password  = $_POST['password']          ?? '';
    $confirm   = $_POST['confirm_password']  ?? '';

    $input = compact('full_name','email','phone');

    // Server-side validation
    if (!$full_name)                              $errors[] = 'Full name is required.';
    elseif (mb_strlen($full_name) < 3)            $errors[] = 'Full name must be at least 3 characters.';
    if (!$email)                                  $errors[] = 'Email address is required.';
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Please enter a valid email address.';
    if (!$phone)                                  $errors[] = 'Phone number is required.';
    if (!$password)                               $errors[] = 'Password is required.';
    elseif (strlen($password) < 8)                $errors[] = 'Password must be at least 8 characters.';
    if ($password && $password !== $confirm)      $errors[] = 'Passwords do not match.';

    if (empty($errors)) {
        $guest  = new Guest();
        $result = $guest->register($full_name, $email, $phone, $password);

        if (!empty($result['success'])) {
            $_SESSION['guest_id']            = $result['id'];
            $_SESSION['guest_name']          = $full_name;
            $_SESSION['guest_last_activity'] = time();
            header('Location: guest_dashboard.php');
            exit;
        } else {
            $errors[] = $result['error'] ?? 'Registration failed. Please try again.';
        }
    }
}

$page_title = 'Create Account — Wind Land Hotel';
$base_path  = '../../';
include '../../includes/header.php';
?>

<!-- Page hero -->
<section class="page-hero" aria-labelledby="reg-title">
  <div class="container">
    <p class="page-hero__label">Join Wind Land Hotel</p>
    <h1 id="reg-title">Create your account</h1>
    <p>Book smart rooms and control your stay from anywhere.</p>
  </div>
</section>

<!-- Registration form -->
<section class="section">
  <div class="container container--narrow">

    <div class="auth-card fade-in">

      <div class="auth-card__badge">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
        New Guest Account
      </div>

      <h2>Create your account</h2>
      <p class="auth-sub">Fill in your details to start booking smart rooms at Wind Land Hotel.</p>

      <?php if (!empty($errors)): ?>
        <?php foreach ($errors as $err): ?>
          <div class="alert alert--error" role="alert">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
            <?php echo htmlspecialchars($err); ?>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>

      <form id="register-form"
            action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>"
            method="POST" novalidate>

        <div class="flex-col gap-16">

          <div class="form-group">
            <label class="form-label" for="full_name">Full Name</label>
            <input class="form-input" type="text" id="full_name" name="full_name"
                   placeholder="e.g. Amara Nkurunziza"
                   value="<?php echo htmlspecialchars($input['full_name']); ?>"
                   autocomplete="name" required />
            <span class="form-error" role="alert"></span>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label" for="email">Email Address</label>
              <input class="form-input" type="email" id="email" name="email"
                     placeholder="you@example.com"
                     value="<?php echo htmlspecialchars($input['email']); ?>"
                     autocomplete="email" required />
              <span class="form-error" role="alert"></span>
            </div>
            <div class="form-group">
              <label class="form-label" for="phone">Phone Number</label>
              <input class="form-input" type="tel" id="phone" name="phone"
                     placeholder="+250 780 000 000"
                     value="<?php echo htmlspecialchars($input['phone']); ?>"
                     autocomplete="tel" required />
              <span class="form-error" role="alert"></span>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label" for="password">Password</label>
            <div class="input-wrap">
              <input class="form-input" type="password" id="password" name="password"
                     placeholder="Minimum 8 characters"
                     autocomplete="new-password" required />
              <button type="button" class="toggle-pw" aria-label="Show password">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
              </button>
            </div>
            <span class="form-error" role="alert"></span>
          </div>

          <div class="form-group">
            <label class="form-label" for="confirm_password">Confirm Password</label>
            <div class="input-wrap">
              <input class="form-input" type="password" id="confirm_password" name="confirm_password"
                     placeholder="Repeat your password"
                     autocomplete="new-password" required />
              <button type="button" class="toggle-pw" aria-label="Show password">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
              </button>
            </div>
            <span class="form-error" role="alert"></span>
          </div>

          <button type="submit" class="btn btn--forest btn--full btn--lg">
            Create Account
          </button>

        </div>

      </form>

      <div class="auth-divider"><span>or</span></div>
      <p class="auth-footer">Already have an account? <a href="login.php">Login here</a></p>

    </div>

  </div>
</section>

<?php include '../../includes/footer.php'; ?>
