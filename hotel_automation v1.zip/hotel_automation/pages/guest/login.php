<?php
/**
 * Wind Land Hotel — Guest Login
 * Backend: authenticates guest and starts session.
 */

require_once '../../config/config.php';
require_once '../../config/Database.php';
require_once '../../classes/Guest.php';

// Already logged in → go straight to dashboard (or redirect target)
if (isset($_SESSION['guest_id'])) {
    $go = $_GET['redirect'] ?? $_POST['redirect'] ?? 'guest_dashboard.php';
    // Safety: only allow relative paths within our app (no external redirects)
    $go = preg_replace('/[^a-zA-Z0-9\.\?\=\&\_\-\/]/', '', $go);
    header('Location: ' . $go);
    exit;
}

$error = '';
// Carry redirect through the form
$redirect = htmlspecialchars(trim($_GET['redirect'] ?? $_POST['redirect'] ?? ''), ENT_QUOTES);

if (isset($_SESSION['timeout_msg'])) {
    $error = $_SESSION['timeout_msg'];
    unset($_SESSION['timeout_msg']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $email    = trim($_POST['email']    ?? '');
    $password = trim($_POST['password'] ?? '');

    $guest  = new Guest();
    $result = $guest->login($email, $password);

    if ($result) {
        $_SESSION['guest_id']            = $result['id'];
        $_SESSION['guest_name']          = $result['full_name'];
        $_SESSION['guest_last_activity'] = time();
        // Go to the page they originally wanted, or dashboard
        $dest = trim($_POST['redirect'] ?? '');
        $dest = preg_replace('/[^a-zA-Z0-9\.\?\=\&\_\-\/]/', '', $dest);
        header('Location: ' . ($dest ?: 'guest_dashboard.php'));
        exit;
    } else {
        $error = 'Invalid email or password.';
    }
}

// ── HTML below is unchanged ───────────────────────────
$page_title = 'Guest Login — Wind Land Hotel';
$base_path  = '../../';
include '../../includes/header.php';
?>

<div class="auth-wrap">
  <div class="auth-card fade-in">

    <div class="auth-card__badge">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
      Guest Portal
    </div>

    <h2>Welcome back</h2>
    <p class="auth-sub">Log in to access your bookings and room controls.</p>

    <?php if (!empty($error)): ?>
      <div class="alert alert--error" role="alert"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <?php if ($redirect): ?>
      <div class="alert alert--info" role="note">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0;"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        Please log in to complete your booking. You'll be taken straight to the room after login.
      </div>
    <?php endif; ?>

    <form class="login-form" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST" novalidate>
      <?php if ($redirect): ?>
        <input type="hidden" name="redirect" value="<?php echo $redirect; ?>" />
      <?php endif; ?>

      <div style="display:flex;flex-direction:column;gap:18px;">

        <div class="form-group">
          <label class="form-label" for="email">Email Address</label>
          <input
            class="form-input"
            type="email"
            id="email"
            name="email"
            placeholder="you@example.com"
            value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
            autocomplete="email"
            required
          />
          <span class="form-error" role="alert"></span>
        </div>

        <div class="form-group">
          <label class="form-label" for="password">Password</label>
          <div class="input-wrap">
            <input
              class="form-input"
              type="password"
              id="password"
              name="password"
              placeholder="Your password"
              autocomplete="current-password"
              required
            />
            <button type="button" class="toggle-pw" aria-label="Show password">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
            </button>
          </div>
          <span class="form-error" role="alert"></span>
        </div>

        <button type="submit" name="login" class="btn btn--forest btn--full btn--lg" style="margin-top:4px;">
          Login
        </button>

      </div>

    </form>

    <div class="auth-divider"><span>or</span></div>

    <p class="auth-footer">Don't have an account? <a href="register.php<?php echo $redirect ? '?redirect='.urlencode($redirect) : ''; ?>">Register here</a></p>
    <p class="auth-footer" style="margin-top:10px;">
      Are you staff? <a href="../admin/login.php">Staff login &rarr;</a>
    </p>

  </div><!-- /.auth-card -->
</div><!-- /.auth-wrap -->

<?php include '../../includes/footer.php'; ?>
