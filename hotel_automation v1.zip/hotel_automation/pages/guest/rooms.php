<?php
require_once '../../config/config.php';
require_once '../../config/Database.php';
require_once '../../classes/Room.php';
// NO guest_auth here — this page is public

$roomObj = new Room();
$rooms   = $roomObj->getAvailable();

$isLoggedIn = isset($_SESSION['guest_id']);

$page_title = 'Available Rooms — Wind Land Hotel';
$base_path  = '../../';
include '../../includes/header.php';
?>

<!-- ═══ PAGE HERO ════════════════════════════════════════ -->
<section class="page-hero" aria-labelledby="rooms-title">
  <div class="container">
    <p class="page-hero__label">Smart Rooms</p>
    <h1 id="rooms-title">Available Rooms</h1>
    <p>Each room equipped with intelligent automation, PIN access, and smart comfort systems.</p>
  </div>
</section>

<!-- ═══ FILTER + GRID ════════════════════════════════════ -->
<section class="section section--sm" aria-label="Room listings">
  <div class="container">

    <!-- Filter bar + count -->
    <div class="flex-between mb-32" style="flex-wrap:wrap;gap:12px;">
      <div class="filter-bar" role="group" aria-label="Filter rooms by type">
        <button class="filter-btn active" data-filter="all">All Rooms</button>
        <button class="filter-btn" data-filter="single">Single</button>
        <button class="filter-btn" data-filter="double">Double</button>
        <button class="filter-btn" data-filter="suite">Suite</button>
      </div>
      <p class="text-muted" style="font-size:0.88rem;">
        <?php echo count($rooms); ?> room<?php echo count($rooms) !== 1 ? 's' : ''; ?> available
      </p>
    </div>

    <!-- Login notice for guests -->
    <?php if (!$isLoggedIn): ?>
      <div class="alert alert--info mb-24" role="note">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0;"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <span>
          You are browsing as a guest.
          <a href="login.php" style="color:var(--forest);font-weight:600;">Login</a>
          or
          <a href="register.php" style="color:var(--forest);font-weight:600;">create an account</a>
          to book a room.
        </span>
      </div>
    <?php endif; ?>

    <?php if (empty($rooms)): ?>
        <div class="empty-state__icon">🏨</div>
        <h4>No rooms available at the moment</h4>
        <p>Please check back soon or contact reception directly.</p>
        <a href="mailto:info@windlandhotel.rw" class="btn btn--forest mt-16">Contact Reception</a>
      </div>
    <?php else: ?>

      <div class="grid-3" id="rooms-grid">
        <?php foreach ($rooms as $room): ?>
        <article class="room-card fade-in" data-type="<?php echo htmlspecialchars($room['type']); ?>">

          <div class="room-card__header">
            <div>
              <div class="room-card__number"><?php echo htmlspecialchars($room['room_number']); ?></div>
              <div class="room-card__type"><?php echo ucfirst(htmlspecialchars($room['type'])); ?> Room</div>
            </div>
            <div class="room-card__status">
              <span class="status-dot status-dot--available" aria-hidden="true"></span>
              <span>Available</span>
            </div>
          </div>

          <div class="room-card__body">
            <div class="room-card__floor">Floor <?php echo (int)$room['floor']; ?></div>
            <div class="room-card__price">
              $<?php echo number_format((float)$room['price'], 0); ?>
              <span>/ night</span>
            </div>
            <div class="tags">
              <span class="tag tag--forest">Auto Lighting</span>
              <span class="tag tag--forest">Smart AC</span>
              <span class="tag tag--gold">Motion Sensor</span>
              <?php if ($room['type'] === 'suite'): ?>
                <span class="tag tag--gold">Premium Suite</span>
              <?php endif; ?>
            </div>
          </div>

          <div class="room-card__footer">
            <?php if ($isLoggedIn): ?>
              <a href="booking.php?room_id=<?php echo (int)$room['id']; ?>"
                 class="btn btn--forest btn--full btn--sm">
                Book This Room
              </a>
            <?php else: ?>
              <a href="login.php?redirect=booking.php%3Froom_id%3D<?php echo (int)$room['id']; ?>"
                 class="btn btn--forest btn--full btn--sm">
                Book This Room
              </a>
            <?php endif; ?>
          </div>

        </article>
        <?php endforeach; ?>
      </div>

    <?php endif; ?>

  </div>
</section>

<?php include '../../includes/footer.php'; ?>
