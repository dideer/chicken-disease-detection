<?php
require_once '../../config/config.php';
require_once '../../config/Database.php';
require_once '../../classes/Guest.php';
require_once '../../classes/Booking.php';
require_once '../../classes/Pin.php';
require_once '../../includes/guest_auth.php';

$guestObj   = new Guest();
$bookingObj = new Booking();
$guest      = $guestObj->getById((int)$_SESSION['guest_id']);

// Get active booking with room details
$db = Database::getInstance()->getConnection();
$activeBooking = null;
$stmt = $db->prepare(
    "SELECT b.id, b.check_in, b.check_out, b.status, b.created_at,
            r.id AS room_id, r.room_number, r.floor, r.type, r.price
     FROM bookings b
     JOIN rooms r ON b.room_id = r.id
     WHERE b.guest_id = ? AND b.status = 'active'
     ORDER BY b.created_at DESC LIMIT 1"
);
if ($stmt) {
    $gid = (int)$_SESSION['guest_id'];
    $stmt->bind_param('i', $gid);
    $stmt->execute();
    $activeBooking = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

$hasActiveBooking = !empty($activeBooking);
$activePin = null;
if ($hasActiveBooking) {
    $pinObj    = new Pin();
    $activePin = $pinObj->getByBooking((int)$activeBooking['id']);
}

// All bookings for history section
$allBookings = [];
$stmt2 = $db->prepare(
    "SELECT b.id, b.check_in, b.check_out, b.status, b.created_at,
            r.room_number, r.type, r.floor
     FROM bookings b
     JOIN rooms r ON b.room_id = r.id
     WHERE b.guest_id = ?
     ORDER BY b.created_at DESC"
);
if ($stmt2) {
    $gid = (int)$_SESSION['guest_id'];
    $stmt2->bind_param('i', $gid);
    $stmt2->execute();
    $allBookings = $stmt2->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt2->close();
}
$bookingCount = count($allBookings);

// Flash message
$flashSuccess = '';
if (isset($_GET['success']) && $_GET['success'] === 'checked_out') {
    $flashSuccess = 'You have successfully checked out. We hope to see you again!';
}

$page_title = 'My Dashboard — Wind Land Hotel';
$base_path  = '../../';
include '../../includes/header.php';
?>

<!-- ═══ GUEST TOP BAR ══════════════════════════════════════ -->
<div style="background:var(--paper);border-bottom:1px solid var(--border);padding:10px 0;margin-top:72px;">
  <div class="container flex-between" style="flex-wrap:wrap;gap:10px;">
    <p style="font-size:0.83rem;color:var(--text-muted);">
      Logged in as
      <strong style="color:var(--text-dark);"><?php echo htmlspecialchars($_SESSION['guest_name']); ?></strong>
    </p>
    <div class="flex gap-12" style="flex-wrap:wrap;align-items:center;">
      <a href="rooms.php" class="btn btn--ghost btn--sm">Browse Rooms</a>
      <a href="logout.php" class="btn btn--danger btn--sm">Logout</a>
    </div>
  </div>
</div>

<!-- ═══ HERO WELCOME ══════════════════════════════════════ -->
<section class="page-hero" aria-labelledby="dash-title">
  <div class="container">
    <p class="page-hero__label">My Dashboard</p>
    <h1 id="dash-title">
      Welcome back,<br>
      <?php echo htmlspecialchars($_SESSION['guest_name']); ?>
    </h1>
    <p>Manage your stay at Wind Land Hotel.</p>
    <?php if ($hasActiveBooking): ?>
      <div class="mt-16">
        <span class="room-number-badge">
          Currently in Room <?php echo htmlspecialchars($activeBooking['room_number']); ?>
        </span>
      </div>
    <?php endif; ?>
  </div>
</section>

<?php if ($flashSuccess): ?>
<div class="container mt-24">
  <div class="alert alert--success" role="alert">
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
    <?php echo htmlspecialchars($flashSuccess); ?>
  </div>
</div>
<?php endif; ?>

<!-- ═══ QUICK ACTION CARDS ════════════════════════════════ -->
<section class="section section--sm" aria-label="Quick actions">
  <div class="container">

    <div class="grid-4">

      <!-- Browse Rooms -->
      <div class="card">
        <div class="card__body text-center">
          <div style="font-size:2rem;margin-bottom:12px;">🏨</div>
          <h4>Browse Rooms</h4>
          <p class="text-muted mt-8" style="font-size:0.85rem;">View available rooms and book your stay.</p>
          <a href="rooms.php" class="btn btn--forest btn--full btn--sm mt-16">View Rooms</a>
        </div>
      </div>

      <!-- My Bookings -->
      <div class="card">
        <div class="card__body text-center">
          <div style="font-size:2rem;margin-bottom:12px;">📋</div>
          <h4>My Bookings</h4>
          <p class="text-muted mt-8" style="font-size:0.85rem;"><?php echo $bookingCount; ?> total booking<?php echo $bookingCount !== 1 ? 's' : ''; ?></p>
          <a href="#my-bookings" class="btn btn--outline-dark btn--full btn--sm mt-16">View Bookings</a>
        </div>
      </div>

      <!-- Room Control -->
      <div class="card">
        <div class="card__body text-center">
          <div style="font-size:2rem;margin-bottom:12px;">🎛️</div>
          <h4>Room Control</h4>
          <p class="text-muted mt-8" style="font-size:0.85rem;">Control lights, AC and door.</p>
          <?php if ($hasActiveBooking): ?>
            <a href="room_control.php" class="btn btn--primary btn--full btn--sm mt-16">Open Panel</a>
          <?php else: ?>
            <button class="btn btn--ghost btn--full btn--sm mt-16" disabled>No Active Booking</button>
          <?php endif; ?>
        </div>
      </div>

      <!-- My PIN -->
      <div class="card">
        <div class="card__body text-center">
          <div style="font-size:2rem;margin-bottom:12px;">🔑</div>
          <h4>My Door PIN</h4>
          <p class="text-muted mt-8" style="font-size:0.85rem;">Your room access code.</p>
          <?php if ($hasActiveBooking && $activePin): ?>
            <a href="pin_confirm.php?booking_id=<?php echo (int)$activeBooking['id']; ?>"
               class="btn btn--outline-dark btn--full btn--sm mt-16">View PIN</a>
          <?php else: ?>
            <p class="text-muted mt-16" style="font-size:0.82rem;">No active PIN</p>
          <?php endif; ?>
        </div>
      </div>

    </div>

  </div>
</section>

<!-- ═══ ACTIVE BOOKING ════════════════════════════════════ -->
<?php if ($hasActiveBooking): ?>
<section class="section section--sm" style="background:var(--paper);" aria-labelledby="active-title">
  <div class="container">

    <p class="section-label">Current Stay</p>
    <h2 id="active-title" class="section-title">Your Active Booking</h2>

    <div class="card">
      <div class="card__body">

        <!-- Room badge + type -->
        <div class="flex gap-12 mb-16" style="flex-wrap:wrap;align-items:center;">
          <span class="room-number-badge" style="font-size:1rem;padding:8px 20px;">
            Room <?php echo htmlspecialchars($activeBooking['room_number']); ?>
          </span>
          <span class="badge badge--green"><?php echo ucfirst(htmlspecialchars($activeBooking['type'])); ?></span>
          <span class="text-muted" style="font-size:0.83rem;">Floor <?php echo (int)$activeBooking['floor']; ?></span>
        </div>

        <!-- Dates -->
        <div class="booking-summary" style="background:var(--paper);border-color:var(--border);">
          <div class="booking-summary__row" style="border-color:var(--border);">
            <span class="text-muted">Check-in</span>
            <span class="mono"><?php echo date('d M Y', strtotime($activeBooking['check_in'])); ?></span>
          </div>
          <div class="booking-summary__row" style="border-color:var(--border);">
            <span class="text-muted">Check-out</span>
            <span class="mono"><?php echo date('d M Y', strtotime($activeBooking['check_out'])); ?></span>
          </div>
          <div class="booking-summary__row" style="border-color:var(--border);">
            <span class="text-muted">Nights remaining</span>
            <span class="mono">
              <?php
                $today = new DateTime('today');
                $checkout = new DateTime($activeBooking['check_out']);
                $diff = max(0, (int)$today->diff($checkout)->days);
                echo $diff . ' night' . ($diff !== 1 ? 's' : '');
              ?>
            </span>
          </div>
        </div>

        <!-- PIN display -->
        <?php if ($activePin): ?>
          <div class="mt-24">
            <p class="section-label">Your Access PIN</p>
            <div class="pin-display" role="group" aria-label="Your 6-digit access PIN">
              <?php foreach (str_split($activePin['pin_code']) as $digit): ?>
                <div class="pin-digit"><?php echo htmlspecialchars($digit); ?></div>
              <?php endforeach; ?>
            </div>
            <p class="form-help mt-16">Enter room number first, then this PIN at the door keypad.</p>
          </div>
        <?php endif; ?>

        <!-- Actions -->
        <div class="flex gap-12 mt-24" style="flex-wrap:wrap;">
          <a href="room_control.php" class="btn btn--forest">Go to Room Control</a>
          <a href="checkout.php" class="btn btn--ghost"
             onclick="return confirm('Are you sure you want to check out?');">Check Out</a>
        </div>

      </div>
    </div>

  </div>
</section>
<?php endif; ?>

<!-- ═══ ALL BOOKINGS ══════════════════════════════════════ -->
<section class="section" id="my-bookings" aria-labelledby="history-title">
  <div class="container">

    <p class="section-label">Booking History</p>
    <h2 id="history-title" class="section-title">My Bookings</h2>

    <?php if (empty($allBookings)): ?>
      <div class="empty-state">
        <div class="empty-state__icon">📋</div>
        <h4>No bookings yet</h4>
        <p>You haven't made any bookings. Start by choosing a room.</p>
        <a href="rooms.php" class="btn btn--forest mt-16">Book a Room</a>
      </div>
    <?php else: ?>
      <div class="grid-2">
        <?php foreach ($allBookings as $b):
          $statusBadge = match($b['status']) {
              'active'      => 'badge--green',
              'checked_out' => 'badge--gray',
              'cancelled'   => 'badge--red',
              default       => 'badge--gray',
          };
          $statusLabel = match($b['status']) {
              'active'      => 'Active Stay',
              'checked_out' => 'Completed',
              'cancelled'   => 'Cancelled',
              default       => ucfirst($b['status']),
          };
        ?>
        <div class="card">
          <div class="card__body">
            <div class="flex-between mb-16">
              <div>
                <h4><?php echo ucfirst(htmlspecialchars($b['type'])); ?> Room</h4>
                <p class="text-muted" style="font-size:0.8rem;margin-top:3px;">Floor <?php echo (int)$b['floor']; ?></p>
              </div>
              <span class="room-number-badge"><?php echo htmlspecialchars($b['room_number']); ?></span>
            </div>

            <div class="booking-summary" style="background:var(--paper);border-color:var(--border);">
              <div class="booking-summary__row" style="border-color:var(--border);">
                <span class="text-muted">Check-in</span>
                <span class="mono" style="font-size:0.85rem;"><?php echo date('d M Y', strtotime($b['check_in'])); ?></span>
              </div>
              <div class="booking-summary__row" style="border-color:transparent;">
                <span class="text-muted">Check-out</span>
                <span class="mono" style="font-size:0.85rem;"><?php echo date('d M Y', strtotime($b['check_out'])); ?></span>
              </div>
            </div>

            <div class="flex-between mt-16">
              <span class="badge <?php echo $statusBadge; ?>"><?php echo $statusLabel; ?></span>
              <?php if ($b['status'] === 'active'): ?>
                <a href="room_control.php" class="btn btn--forest btn--sm">Manage Room</a>
              <?php endif; ?>
            </div>

          </div>
        </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

  </div>
</section>

<?php include '../../includes/footer.php'; ?>
