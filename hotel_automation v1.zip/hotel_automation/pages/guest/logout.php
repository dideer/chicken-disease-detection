<?php
/**
 * Wind Land Hotel — Guest Logout
 * Destroys the guest session and redirects to the login page.
 */

require_once '../../config/config.php';  // starts session if not already started

session_unset();
session_destroy();

header('Location: ' . BASE_URL . '/pages/guest/login.php');
exit;
