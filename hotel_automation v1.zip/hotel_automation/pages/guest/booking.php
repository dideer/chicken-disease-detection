<?php
require_once '../../config/config.php';
require_once '../../config/Database.php';
require_once '../../classes/Room.php';
require_once '../../classes/Booking.php';
require_once '../../classes/Pin.php';
require_once '../../includes/guest_auth.php';

$room_id = (int)($_GET['room_id'] ?? 0);
$roomObj = new Room();
$room    = $roomObj->getById($room_id);

// Redirect if room not found or not available
if (!$room || $room['status'] !== 'available') {
    header('Location: rooms.php');
    exit;
}

$errors = [];
$today  = date('Y-m-d');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $check_in  = trim($_POST['check_in']  ?? '');
    $check_out = trim($_POST['check_out'] ?? '');
    $post_room = (int)($_POST['room_id']  ?? 0);

    // Validate
    if (!$check_in)                                    $errors[] = 'Check-in date is required.';
    elseif ($check_in < $today)                        $errors[] = 'Check-in date cannot be in the past.';
    if (!$check_out)                                   $errors[] = 'Check-out date is required.';
    if ($check_in && $check_out && $check_out <= $check_in) $errors[] = 'Check-out must be after check-in.';

    if (empty($errors)) {
        // Re-check room availability
        $freshRoom = $roomObj->getById($post_room ?: $room_id);
        if (!$freshRoom || $freshRoom['status'] !== 'available') {
            $errors[] = 'Sorry, this room is no longer available. Please choose another.';
        } else {
            // Insert booking
            $db   = Database::getInstance()->getConnection();
            $gid  = (int)$_SESSION['guest_id'];
            $rid  = (int)$freshRoom['id'];
            $stmt = $db->prepare(
                "INSERT INTO bookings (guest_id, room_id, check_in, check_out, status)
                 VALUES (?, ?, ?, ?, 'active')"
            );
            if (!$stmt) {
                $errors[] = 'Booking failed. Please try again.';
            } else {
                $stmt->bind_param('iiss', $gid, $rid, $check_in, $check_out);
                $ok = $stmt->execute();
                $booking_id = (int)$db->insert_id;
                $stmt->close();

                if (!$ok || !$booking_id) {
                    $errors[] = 'Booking failed. Please try again.';
                } else {
                    // Mark room occupied
                    $roomObj->updateStatus($rid, 'occupied');

                    // Generate PIN — expires at checkout noon
                    $pinObj    = new Pin();
                    $expires   = $check_out . ' 12:00:00';
                    $pinObj->generate($booking_id, $rid, $expires);

                    header('Location: pin_confirm.php?booking_id=' . $booking_id);
                    exit;
                }
            }
        }
    }
}

$page_title = 'Book a Room — Wind Land Hotel';
$base_path  = '../../';
include '../../includes/header.php';
?>

<!-- ═══ PAGE HERO ════════════════════════════════════════ -->
<section class="page-hero" aria-labelledby="book-title">
  <div class="container">
    <p class="page-hero__label">Reserve Your Stay</p>
    <h1 id="book-title">Book Room <?php echo htmlspecialchars($room['room_number']); ?></h1>
    <p>
      <?php echo ucfirst(htmlspecialchars($room['type'])); ?>
      &middot; $<?php echo number_format((float)$room['price'], 0); ?> per night
      &middot; Floor <?php echo (int)$room['floor']; ?>
    </p>
  </div>
</section>

<!-- ═══ BOOKING FORM ════════════════════════════════════ -->
<section class="section" aria-label="Booking form">
  <div class="container">

    <div class="grid-2">

      <!-- Room summary -->
      <div>
        <p class="section-label">Room Details</p>
        <div class="booking-summary">
          <h4 style="color:var(--white);margin-bottom:16px;">Room Summary</h4>
          <div class="booking-summary__row">
            <span>Room Number</span>
            <span class="mono"><?php echo htmlspecialchars($room['room_number']); ?></span>
          </div>
          <div class="booking-summary__row">
            <span>Type</span>
            <span><?php echo ucfirst(htmlspecialchars($room['type'])); ?></span>
          </div>
          <div class="booking-summary__row">
            <span>Floor</span>
            <span>Floor <?php echo (int)$room['floor']; ?></span>
          </div>
          <div class="booking-summary__row">
            <span>Price per night</span>
            <span>$<?php echo number_format((float)$room['price'], 2); ?></span>
          </div>
          <div class="booking-summary__total">
            <span id="total-nights">Select dates</span>
            <span id="total-price">—</span>
          </div>
        </div>

        <div class="tags mt-16">
          <span class="tag tag--forest">Auto Lighting</span>
          <span class="tag tag--forest">Smart AC</span>
          <span class="tag tag--gold">Motion Sensor</span>
          <?php if ($room['type'] === 'suite'): ?>
            <span class="tag tag--gold">Premium Suite</span>
          <?php endif; ?>
        </div>
      </div>

      <!-- Booking form -->
      <div>
        <div class="card">
          <div class="card__body">

            <h4 class="mb-24">Select Your Dates</h4>

            <?php foreach ($errors as $err): ?>
              <div class="alert alert--error mb-16" role="alert">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                <?php echo htmlspecialchars($err); ?>
              </div>
            <?php endforeach; ?>

            <form id="booking-form"
                  action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) . '?room_id=' . $room_id; ?>"
                  method="POST"
                  data-price="<?php echo (float)$room['price']; ?>">

              <input type="hidden" name="room_id" value="<?php echo (int)$room['id']; ?>" />

              <div class="flex-col gap-16">

                <div class="form-group">
                  <label class="form-label" for="check_in">Check-in Date</label>
                  <input class="form-input" type="date" id="check_in" name="check_in"
                         min="<?php echo $today; ?>"
                         value="<?php echo htmlspecialchars($_POST['check_in'] ?? ''); ?>"
                         required />
                  <span class="form-error" role="alert"></span>
                </div>

                <div class="form-group">
                  <label class="form-label" for="check_out">Check-out Date</label>
                  <input class="form-input" type="date" id="check_out" name="check_out"
                         value="<?php echo htmlspecialchars($_POST['check_out'] ?? ''); ?>"
                         required />
                  <span class="form-error" role="alert"></span>
                </div>

                <!-- Total price calculator -->
                <div class="booking-summary__total" style="background:var(--paper);padding:14px 16px;border-radius:var(--radius-sm);">
                  <span id="total-nights" class="text-muted" style="font-size:0.88rem;">Select dates above</span>
                  <span id="total-price" style="font-family:var(--font-head);font-size:1.3rem;color:var(--forest);font-weight:600;">—</span>
                </div>

                <button type="submit" class="btn btn--primary btn--full btn--lg">
                  Confirm Booking &amp; Get PIN
                </button>

              </div>

            </form>

          </div>
        </div>
      </div>

    </div>

  </div>
</section>

<?php include '../../includes/footer.php'; ?>
