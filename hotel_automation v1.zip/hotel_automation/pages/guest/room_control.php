<?php
require_once '../../config/config.php';
require_once '../../config/Database.php';
require_once '../../classes/Booking.php';
require_once '../../classes/Pin.php';
require_once '../../includes/guest_auth.php';

$db = Database::getInstance()->getConnection();

// Get active booking with room details
$activeBooking = null;
$stmt = $db->prepare(
    "SELECT b.id, b.check_in, b.check_out, b.status, b.guest_id,
            r.id AS room_id, r.room_number, r.floor, r.type
     FROM bookings b
     JOIN rooms r ON b.room_id = r.id
     WHERE b.guest_id = ? AND b.status = 'active'
     ORDER BY b.created_at DESC LIMIT 1"
);
if ($stmt) {
    $gid = (int)$_SESSION['guest_id'];
    $stmt->bind_param('i', $gid);
    $stmt->execute();
    $activeBooking = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

if (!$activeBooking) {
    header('Location: guest_dashboard.php');
    exit;
}

$room_id = (int)$activeBooking['room_id'];

// Latest temperature/humidity log
$latestTemp = null;
$tStmt = $db->prepare(
    "SELECT temperature, humidity, automation_active
     FROM temperature_logs WHERE room_id = ? ORDER BY recorded_at DESC LIMIT 1"
);
if ($tStmt) {
    $tStmt->bind_param('i', $room_id);
    $tStmt->execute();
    $latestTemp = $tStmt->get_result()->fetch_assoc();
    $tStmt->close();
}

// Latest motion log
$latestMotion = null;
$mStmt = $db->prepare(
    "SELECT motion_detected FROM motion_logs WHERE room_id = ? ORDER BY recorded_at DESC LIMIT 1"
);
if ($mStmt) {
    $mStmt->bind_param('i', $room_id);
    $mStmt->execute();
    $row = $mStmt->get_result()->fetch_assoc();
    $latestMotion = $row ? (bool)$row['motion_detected'] : false;
    $mStmt->close();
}

// PIN
$pinObj = new Pin();
$pin    = $pinObj->getByBooking((int)$activeBooking['id']);

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'toggle_temp_automation' && $latestTemp !== null) {
        $newVal = ($latestTemp['automation_active'] ? 0 : 1);
        $uStmt  = $db->prepare(
            "UPDATE temperature_logs SET automation_active = ?
             WHERE room_id = ? ORDER BY recorded_at DESC LIMIT 1"
        );
        if ($uStmt) {
            $uStmt->bind_param('ii', $newVal, $room_id);
            $uStmt->execute();
            $uStmt->close();
        }
        header('Location: ' . htmlspecialchars($_SERVER['PHP_SELF']));
        exit;
    }

    if ($action === 'checkout') {
        $bookingObj = new Booking();
        $pinObj->expire((int)$activeBooking['id']);
        $bookingObj->checkout((int)$activeBooking['id']);
        header('Location: guest_dashboard.php?success=checked_out');
        exit;
    }

    header('Location: ' . htmlspecialchars($_SERVER['PHP_SELF']));
    exit;
}

$automationActive = (bool)($latestTemp['automation_active'] ?? false);

$page_title = 'Room Control — Wind Land Hotel';
$base_path  = '../../';
include '../../includes/header.php';
?>

<!-- ═══ PAGE HERO ════════════════════════════════════════ -->
<section class="page-hero" aria-labelledby="ctrl-title">
  <div class="container">
    <p class="page-hero__label">Room <?php echo htmlspecialchars($activeBooking['room_number']); ?></p>
    <h1 id="ctrl-title">Room Control Panel</h1>
    <p>Manage your room automation and comfort settings.</p>
    <div class="flex gap-12 mt-16" style="flex-wrap:wrap;align-items:center;">
      <span class="room-number-badge">Room <?php echo htmlspecialchars($activeBooking['room_number']); ?></span>
      <span class="text-muted" style="color:rgba(253,252,248,0.55);font-size:0.85rem;">
        <?php echo htmlspecialchars($_SESSION['guest_name']); ?>
      </span>
    </div>
  </div>
</section>

<!-- ═══ SENSOR CARDS ══════════════════════════════════════ -->
<section class="section section--sm" aria-label="Live sensors" id="sensor-panel">
  <div class="container">

    <p class="section-label">Live Sensors</p>

    <div class="grid-4">

      <!-- Temperature -->
      <div class="sensor-card">
        <div class="sensor-card__icon">🌡️</div>
        <div class="sensor-card__value">
          <span id="sensor-temp"><?php echo htmlspecialchars($latestTemp['temperature'] ?? '--'); ?></span>
          <span class="sensor-card__unit">°C</span>
        </div>
        <div class="sensor-card__label">Temperature</div>
        <div class="sensor-card__status">
          <?php if ($latestTemp && $latestTemp['temperature'] > TEMP_THRESHOLD): ?>
            <span class="status-dot status-dot--alert"></span>
            Above threshold — AC running
          <?php else: ?>
            <span class="status-dot status-dot--available"></span>
            Normal range
          <?php endif; ?>
        </div>
      </div>

      <!-- Humidity -->
      <div class="sensor-card">
        <div class="sensor-card__icon">💧</div>
        <div class="sensor-card__value">
          <span id="sensor-humidity"><?php echo htmlspecialchars($latestTemp['humidity'] ?? '--'); ?></span>
          <span class="sensor-card__unit">%</span>
        </div>
        <div class="sensor-card__label">Humidity</div>
        <div class="sensor-card__status">
          <span class="status-dot status-dot--available"></span>
          Live reading
        </div>
      </div>

      <!-- Lighting -->
      <div class="sensor-card">
        <div class="sensor-card__icon">💡</div>
        <div class="sensor-card__value" id="sensor-light">Auto</div>
        <div class="sensor-card__label">Lighting Mode</div>
        <div class="sensor-card__status">
          <span class="status-dot status-dot--available"></span>
          Motion-based
        </div>
      </div>

      <!-- Motion -->
      <div class="sensor-card">
        <div class="sensor-card__icon">🚶</div>
        <div class="sensor-card__value" id="sensor-motion">
          <?php echo $latestMotion ? 'Detected' : 'None'; ?>
        </div>
        <div class="sensor-card__label">Motion Sensor</div>
        <div class="sensor-card__status">
          <span class="status-dot status-dot--<?php echo $latestMotion ? 'alert' : 'available'; ?>"></span>
          <?php echo $latestMotion ? 'Movement active' : 'No movement'; ?>
        </div>
      </div>

    </div>

  </div>
</section>

<!-- ═══ AUTOMATION CONTROLS ═══════════════════════════════ -->
<section class="section section--sm" style="background:var(--paper);" aria-label="Automation settings">
  <div class="container">

    <p class="section-label">Automation Settings</p>
    <h2 class="section-title mb-24">Room Controls</h2>

    <div class="flex-col gap-12" style="max-width:600px;">

      <!-- Temperature AC toggle -->
      <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
        <input type="hidden" name="action" value="toggle_temp_automation" />
        <label class="toggle-wrap <?php echo $automationActive ? 'active' : ''; ?>" aria-label="Toggle temperature-based AC">
          <div class="toggle-info">
            <span class="toggle-label">Temperature-based AC</span>
            <span class="toggle-desc">Fan turns on automatically when temperature exceeds <?php echo TEMP_THRESHOLD; ?>°C</span>
          </div>
          <div class="toggle-switch">
            <input type="checkbox" <?php echo $automationActive ? 'checked' : ''; ?>
                   onchange="this.closest('form').submit()" />
            <span class="toggle-track"></span>
            <span class="toggle-thumb"></span>
          </div>
        </label>
      </form>

      <!-- Motion lighting toggle (frontend only) -->
      <label class="toggle-wrap active" aria-label="Toggle motion-based lighting">
        <div class="toggle-info">
          <span class="toggle-label">Motion-based Lighting</span>
          <span class="toggle-desc">Lights turn on automatically when movement is detected in the room</span>
        </div>
        <div class="toggle-switch">
          <input type="checkbox" checked />
          <span class="toggle-track"></span>
          <span class="toggle-thumb"></span>
        </div>
      </label>

    </div>

  </div>
</section>

<!-- ═══ DOOR CONTROL ══════════════════════════════════════ -->
<section class="section section--sm" aria-label="Door control">
  <div class="container">

    <p class="section-label">Door Control</p>

    <div class="card" style="max-width:600px;">
      <div class="card__body">
        <h4 class="mb-24">Door Control</h4>

        <!-- Unlock from inside -->
        <div class="flex-between mb-24" style="flex-wrap:wrap;gap:16px;">
          <div>
            <p style="font-weight:600;font-size:0.9rem;">Unlock door from inside</p>
            <p class="text-muted" style="font-size:0.82rem;margin-top:3px;">Opens door without PIN — use when leaving the room</p>
            <p class="text-muted" style="font-size:0.75rem;margin-top:6px;font-style:italic;">(Hardware integration — coming soon)</p>
          </div>
          <button class="btn btn--forest" id="unlock-door-btn" type="button">Unlock Door</button>
        </div>

        <div class="divider"></div>

        <!-- PIN display -->
        <div class="mt-24">
          <p style="font-weight:600;font-size:0.9rem;margin-bottom:14px;">Your Door PIN</p>
          <?php if ($pin): ?>
            <div class="pin-display" role="group" aria-label="Your 6-digit access PIN">
              <?php foreach (str_split($pin['pin_code']) as $digit): ?>
                <div class="pin-digit"><?php echo htmlspecialchars($digit); ?></div>
              <?php endforeach; ?>
            </div>
            <p class="form-help mt-12">Enter room number first, then this PIN at the door keypad.</p>
          <?php else: ?>
            <p class="text-muted" style="font-size:0.85rem;">No active PIN found.</p>
          <?php endif; ?>
        </div>

      </div>
    </div>

  </div>
</section>

<!-- ═══ CHECKOUT ══════════════════════════════════════════ -->
<section class="section section--sm" aria-label="Check out">
  <div class="container">

    <div class="card" style="max-width:600px;border-color:rgba(192,57,43,0.3);">
      <div class="card__body">
        <h4 class="mb-8">Check Out</h4>
        <p class="text-muted mb-16" style="font-size:0.88rem;">
          Ready to leave? Checking out will expire your PIN and free the room.
        </p>

        <div class="booking-summary" style="background:var(--paper);border-color:var(--border);margin-bottom:20px;">
          <div class="booking-summary__row" style="border-color:var(--border);">
            <span class="text-muted">Check-in</span>
            <span class="mono" style="color:var(--text-dark);"><?php echo date('d M Y', strtotime($activeBooking['check_in'])); ?></span>
          </div>
          <div class="booking-summary__row" style="border-color:transparent;">
            <span class="text-muted">Check-out</span>
            <span class="mono" style="color:var(--text-dark);"><?php echo date('d M Y', strtotime($activeBooking['check_out'])); ?></span>
          </div>
        </div>

        <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>"
              onsubmit="return confirm('Are you sure you want to check out?');">
          <input type="hidden" name="action" value="checkout" />
          <button type="submit" class="btn btn--danger">Check Out Now</button>
        </form>

      </div>
    </div>

  </div>
</section>

<script>
// Unlock door feedback
document.getElementById('unlock-door-btn')?.addEventListener('click', function() {
  this.textContent = 'Unlocking…';
  this.disabled = true;
  setTimeout(() => {
    this.textContent = '✓ Door Unlocked';
    this.classList.add('btn--forest');
    setTimeout(() => {
      this.textContent = 'Unlock Door';
      this.disabled = false;
    }, 3000);
  }, 900);
});
</script>

<?php include '../../includes/footer.php'; ?>
