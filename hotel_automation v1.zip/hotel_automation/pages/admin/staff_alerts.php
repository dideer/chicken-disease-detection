<?php
require_once '../../includes/staff_bootstrap.php';
$pageTitle = 'Alerts';
include '../../includes/staff_layout.php';

$occupiedRooms = array_filter($assignedRooms, fn($r) => $r['status'] === 'occupied');
?>

    <!-- Page heading -->
    <div style="margin-bottom:20px;">
      <h2 style="font-size:1.7rem;">Room Alerts</h2>
      <p style="font-size:0.85rem;color:var(--text-muted);margin-top:4px;">
        Rooms in your assigned range that need attention
      </p>
    </div>

    <!-- Flash messages -->
    <?php if ($flashSuccess): ?>
      <div class="alert alert--success" role="alert" style="margin-bottom:20px;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
        <?php echo htmlspecialchars($flashSuccess); ?>
      </div>
    <?php endif; ?>
    <?php if ($flashError): ?>
      <div class="alert alert--error" role="alert" style="margin-bottom:20px;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <?php echo htmlspecialchars($flashError); ?>
      </div>
    <?php endif; ?>

    <?php if ($noAssignment): ?>
      <div class="alert alert--warning" role="alert" style="padding:20px 22px;">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0;"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
        <div>
          <strong>You have no rooms assigned yet.</strong><br>
          <span style="font-size:0.85rem;">Please contact your Super Admin to assign a room range to your account.</span>
        </div>
      </div>
    <?php elseif (empty($occupiedRooms)): ?>
      <div class="alert alert--success" role="status">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
        No active alerts. All rooms are running normally.
      </div>
    <?php else: ?>

      <!-- Alert count badge -->
      <div style="margin-bottom:20px;">
        <span class="badge badge--red" style="font-size:0.82rem;padding:6px 14px;">
          <?php echo count($occupiedRooms); ?> occupied room<?php echo count($occupiedRooms) !== 1 ? 's' : ''; ?> require attention
        </span>
      </div>

      <!-- Alert cards -->
      <?php foreach ($occupiedRooms as $r):
        $rId    = (int)$r['id'];
        $rGuest = $activeBookingByRoom[$rId] ?? null;
      ?>
        <div class="alert-room-card">
          <div class="alert-room-card__left">
            <span class="room-number-badge" style="font-size:1rem;padding:8px 18px;">
              <?php echo htmlspecialchars($r['room_number']); ?>
            </span>
            <div>
              <div style="font-weight:600;font-size:0.92rem;">
                <?php echo $rGuest ? htmlspecialchars($rGuest['full_name']) : 'Occupied'; ?>
              </div>
              <?php if ($rGuest): ?>
                <div style="font-size:0.78rem;color:var(--text-muted);margin-top:3px;">
                  <?php echo htmlspecialchars($rGuest['email']); ?>
                </div>
                <div style="font-size:0.75rem;color:var(--text-muted);margin-top:2px;">
                  Check-in: <?php echo date('d M Y', strtotime($rGuest['check_in'])); ?>
                  &rarr; Check-out: <?php echo date('d M Y', strtotime($rGuest['check_out'])); ?>
                </div>
              <?php endif; ?>
              <div style="font-size:0.75rem;color:var(--text-muted);margin-top:2px;">
                Floor <?php echo (int)$r['floor']; ?> &middot; <?php echo ucfirst($r['type']); ?>
              </div>
            </div>
          </div>
          <div class="alert-room-card__right">
            <span class="badge badge--red">Occupied</span>
            <div style="font-size:0.78rem;color:var(--text-muted);max-width:200px;line-height:1.5;text-align:right;">
              Monitor temperature via sensor panel
              <em style="display:block;color:var(--text-light);">(ESP32 integration pending)</em>
            </div>
            <?php if ($rGuest): ?>
              <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:4px;">
                <form method="POST" action="staff_rooms.php"
                      onsubmit="return confirm('Check out guest from room <?php echo htmlspecialchars($r['room_number'], ENT_QUOTES); ?>?');">
                  <input type="hidden" name="action"     value="checkout_guest" />
                  <input type="hidden" name="booking_id" value="<?php echo (int)$rGuest['id']; ?>" />
                  <button type="submit" class="btn btn--forest btn--sm">Checkout</button>
                </form>
              </div>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>

    <?php endif; ?>

<?php include '../../includes/staff_layout_end.php'; ?>
