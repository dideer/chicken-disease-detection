<?php
require_once '../../includes/staff_bootstrap.php';
$pageTitle = 'My Rooms';
include '../../includes/staff_layout.php';
?>

    <!-- Page heading -->
    <div style="margin-bottom:20px;">
      <h2 style="font-size:1.7rem;">My Assigned Rooms</h2>
      <?php if ($assignment): ?>
        <p style="font-size:0.85rem;color:var(--text-muted);margin-top:6px;">
          Managing rooms
          <span class="badge badge--green" style="margin-left:6px;">
            <?php echo htmlspecialchars($assignment['room_from']); ?>
            &ndash;
            <?php echo htmlspecialchars($assignment['room_to']); ?>
          </span>
        </p>
      <?php endif; ?>
    </div>

    <!-- Flash messages -->
    <?php if ($flashSuccess): ?>
      <div class="alert alert--success" role="alert" style="margin-bottom:20px;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
        <?php echo htmlspecialchars($flashSuccess); ?>
      </div>
    <?php endif; ?>
    <?php if ($flashError): ?>
      <div class="alert alert--error" role="alert" style="margin-bottom:20px;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <?php echo htmlspecialchars($flashError); ?>
      </div>
    <?php endif; ?>

    <?php if ($noAssignment): ?>
      <div class="alert alert--warning" role="alert" style="padding:20px 22px;">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0;"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
        <div>
          <strong>You have no rooms assigned yet.</strong><br>
          <span style="font-size:0.85rem;">Please contact your Super Admin to assign a room range to your account.</span>
        </div>
      </div>
    <?php elseif (empty($assignedRooms)): ?>
      <div class="empty-state">
        <div class="empty-state__icon">🏨</div>
        <h4>No rooms in your assigned range yet</h4>
        <p>Contact your Super Admin if you believe this is an error.</p>
      </div>
    <?php else: ?>

      <!-- Stats mini bar -->
      <div class="dash-stats" style="margin-bottom:28px;">
        <div class="dash-stat">
          <div class="dash-stat__label">Total</div>
          <div class="dash-stat__value"><?php echo $total; ?></div>
          <div class="dash-stat__sub">My rooms</div>
        </div>
        <div class="dash-stat">
          <div class="dash-stat__label">Occupied</div>
          <div class="dash-stat__value" style="color:var(--error);"><?php echo $occupied; ?></div>
          <div class="dash-stat__sub">With guests</div>
        </div>
        <div class="dash-stat">
          <div class="dash-stat__label">Available</div>
          <div class="dash-stat__value" style="color:var(--forest);"><?php echo $available; ?></div>
          <div class="dash-stat__sub">Ready to book</div>
        </div>
        <div class="dash-stat">
          <div class="dash-stat__label">Maintenance</div>
          <div class="dash-stat__value" style="color:var(--gold);"><?php echo $maintenance; ?></div>
          <div class="dash-stat__sub">Under service</div>
        </div>
      </div>

      <!-- Rooms table -->
      <div class="card">
        <div class="table-wrap" style="border:none;border-radius:0;">
          <table aria-label="Assigned rooms">
            <thead>
              <tr>
                <th>Room No</th>
                <th>Floor</th>
                <th>Type</th>
                <th>Price</th>
                <th>Status</th>
                <th>Current Guest</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
            <?php foreach ($assignedRooms as $room):
              $roomId        = (int)$room['id'];
              $activeBooking = $activeBookingByRoom[$roomId] ?? null;
              $statusBadge   = match($room['status']) {
                  'occupied'    => 'badge--red',
                  'maintenance' => 'badge--gold',
                  default       => 'badge--green',
              };
            ?>
              <tr>
                <td><span class="room-number-badge"><?php echo htmlspecialchars($room['room_number']); ?></span></td>
                <td>Floor <?php echo (int)$room['floor']; ?></td>
                <td><?php echo ucfirst(htmlspecialchars($room['type'])); ?></td>
                <td><span class="mono">$<?php echo number_format((float)$room['price'], 2); ?>/night</span></td>
                <td><span class="badge <?php echo $statusBadge; ?>"><?php echo ucfirst($room['status']); ?></span></td>
                <td>
                  <?php if ($room['status'] === 'occupied' && $activeBooking): ?>
                    <div>
                      <strong style="font-size:0.88rem;"><?php echo htmlspecialchars($activeBooking['full_name']); ?></strong>
                      <div style="font-size:0.75rem;color:var(--text-muted);margin-top:2px;">
                        <?php echo date('d M', strtotime($activeBooking['check_in'])); ?>
                        &rarr;
                        <?php echo date('d M Y', strtotime($activeBooking['check_out'])); ?>
                      </div>
                    </div>
                  <?php else: ?>
                    <span style="color:var(--text-muted);font-size:0.85rem;">—</span>
                  <?php endif; ?>
                </td>
                <td>
                  <?php if ($room['status'] === 'occupied' && $activeBooking): ?>
                    <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
                      <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>"
                            onsubmit="return confirm('Cancel this booking? Room will be freed.');">
                        <input type="hidden" name="action"     value="cancel_booking" />
                        <input type="hidden" name="booking_id" value="<?php echo (int)$activeBooking['id']; ?>" />
                        <button type="submit" class="btn btn--danger btn--sm">Cancel Booking</button>
                      </form>
                      <span style="font-size:0.73rem;color:var(--text-muted);">
                        Auto-checkout <?php echo date('d M', strtotime($activeBooking['check_out'])); ?>
                      </span>
                    </div>
                  <?php else: ?>
                    <span style="color:var(--text-muted);font-size:0.85rem;">—</span>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>

    <?php endif; ?>

<?php include '../../includes/staff_layout_end.php'; ?>
