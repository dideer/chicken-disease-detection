<?php
/**
 * Wind Land Hotel — Admin / Staff Logout
 * Destroys the admin session and redirects to the staff login page.
 */

require_once '../../config/config.php';  // starts session if not already started

session_unset();
session_destroy();

header('Location: ' . BASE_URL . '/pages/admin/login.php');
exit;
