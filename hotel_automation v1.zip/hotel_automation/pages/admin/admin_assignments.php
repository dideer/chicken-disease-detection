<?php
/**
 * Wind Land Hotel — Room Assignments
 * Self-contained. No header.php / footer.php.
 */

require_once '../../config/config.php';
require_once '../../config/Database.php';
require_once '../../classes/Admin.php';
require_once '../../classes/Room.php';
require_once '../../classes/RoomAssignment.php';
require_once '../../includes/admin_auth.php';

if ($admin_role !== 'super_admin') {
    header('Location: staff_dashboard.php');
    exit;
}

$adminObj  = new Admin();
$assignObj = new RoomAssignment();

/* ── POST handling (PRG) ───────────────────────────────── */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'assign_rooms') {
        $assign_admin_id = (int)($_POST['admin_id']   ?? 0);
        $room_from       = trim($_POST['room_from'] ?? '');
        $room_to         = trim($_POST['room_to']   ?? '');
        $result = $assignObj->assign($assign_admin_id, $room_from, $room_to);
        if (!$result) {
            header('Location: admin_assignments.php?error=range_overlap');
        } else {
            header('Location: admin_assignments.php?success=rooms_assigned');
        }
        exit;
    }

    if ($action === 'remove_assignment') {
        $assignment_id = (int)($_POST['assignment_id'] ?? 0);
        $assignObj->delete($assignment_id);
        header('Location: admin_assignments.php?success=assignment_removed');
        exit;
    }
}

/* ── Load data ─────────────────────────────────────────── */
$staffList   = $adminObj->getAllStaff();
$assignments = $assignObj->getAll();

/* ── Flash messages ────────────────────────────────────── */
$successMessages = [
    'rooms_assigned'     => 'Room range assigned.',
    'assignment_removed' => 'Assignment removed.',
];
$errorMessages = [
    'range_overlap' => 'Room range overlaps existing assignment.',
];
$flashSuccess = isset($_GET['success']) ? ($successMessages[$_GET['success']] ?? '') : '';
$flashError   = isset($_GET['error'])   ? ($errorMessages[$_GET['error']]     ?? '') : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Room Assignments — Wind Land Hotel Admin</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400;1,600&family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="../../assets/css/style.css" />
  <style>
    .admin-topbar {
      position: fixed;
      top: 0; left: 0; right: 0;
      height: 60px;
      background: var(--ink);
      border-bottom: 1px solid rgba(184,150,62,0.2);
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 28px;
      z-index: 1000;
    }
    .admin-topbar__brand {
      font-family: var(--font-head);
      font-size: 1.2rem;
      font-weight: 600;
      color: var(--white);
      letter-spacing: 0.04em;
    }
    .admin-topbar__brand span {
      font-family: var(--font-mono);
      font-size: 0.62rem;
      color: var(--gold);
      letter-spacing: 0.14em;
      text-transform: uppercase;
      display: block;
      margin-top: 2px;
    }
    .admin-topbar__right {
      display: flex;
      align-items: center;
      gap: 16px;
    }
    .admin-topbar__user {
      font-size: 0.82rem;
      color: rgba(253,252,248,0.6);
    }
    .admin-topbar__user strong {
      color: var(--white);
      font-weight: 600;
    }
    .admin-layout {
      padding-top: 60px;
      min-height: 100vh;
      display: flex;
    }
    .admin-sidebar {
      width: 240px;
      background: var(--ink);
      border-right: 1px solid rgba(255,255,255,0.07);
      position: fixed;
      top: 60px;
      left: 0;
      bottom: 0;
      overflow-y: auto;
      padding: 20px 0 32px;
      z-index: 900;
    }
    .admin-content {
      margin-left: 240px;
      flex: 1;
      background: var(--paper);
      padding: 32px;
      min-height: calc(100vh - 60px);
    }
    @media (max-width: 768px) {
      .admin-sidebar { display: none; }
      .admin-content { margin-left: 0; padding: 20px 16px; }
    }
  </style>
</head>
<body>

<!-- TOP NAVBAR -->
<header class="admin-topbar">
  <div class="admin-topbar__brand">
    WindLand Hotel
    <span>Super Admin Panel</span>
  </div>
  <div class="admin-topbar__right">
    <div class="admin-topbar__user">
      Logged in as <strong><?php echo htmlspecialchars($_SESSION['admin_name']); ?></strong>
      &nbsp;<span class="badge badge--gold" style="font-size:0.62rem;">Super Admin</span>
    </div>
    <a href="logout.php" class="btn btn--danger btn--sm">Logout</a>
  </div>
</header>

<div class="admin-layout">

  <!-- SIDEBAR -->
  <aside class="admin-sidebar" role="navigation" aria-label="Admin navigation">
    <div class="admin-nav__section-label">Menu</div>

    <a href="admin_dashboard.php" class="admin-nav__link <?= basename($_SERVER['PHP_SELF'])==='admin_dashboard.php' ? 'active' : '' ?>">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
      Overview
    </a>
    <a href="admin_rooms.php" class="admin-nav__link <?= basename($_SERVER['PHP_SELF'])==='admin_rooms.php' ? 'active' : '' ?>">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
      Rooms
    </a>
    <a href="admin_staff.php" class="admin-nav__link <?= basename($_SERVER['PHP_SELF'])==='admin_staff.php' ? 'active' : '' ?>">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
      Staff
    </a>
    <a href="admin_assignments.php" class="admin-nav__link <?= basename($_SERVER['PHP_SELF'])==='admin_assignments.php' ? 'active' : '' ?>">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
      Assignments
    </a>

    <div class="admin-nav__section-label" style="margin-top:16px;">Clock</div>
    <div style="padding:6px 24px;font-family:var(--font-mono);font-size:0.72rem;color:rgba(253,252,248,0.3);">
      <span id="clock"></span>
    </div>
  </aside>

  <!-- MAIN CONTENT -->
  <div class="admin-content">

    <!-- Page heading -->
    <div style="margin-bottom:20px;">
      <h2 style="font-size:1.7rem;">Room Assignments</h2>
      <p style="font-size:0.85rem;color:var(--text-muted);margin-top:4px;">Assign a room number range to a staff member.</p>
    </div>

    <!-- Flash messages -->
    <?php if ($flashSuccess): ?>
      <div class="alert alert--success" role="alert" style="margin-bottom:20px;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
        <?php echo htmlspecialchars($flashSuccess); ?>
      </div>
    <?php endif; ?>
    <?php if ($flashError): ?>
      <div class="alert alert--error" role="alert" style="margin-bottom:20px;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <?php echo htmlspecialchars($flashError); ?>
      </div>
    <?php endif; ?>

    <!-- Assign form (always visible) -->
    <div class="card" style="margin-bottom:28px;">
      <div class="card__body">
        <h4 style="font-size:0.95rem;margin-bottom:16px;">Assign Room Range</h4>
        <form method="POST" action="admin_assignments.php">
          <input type="hidden" name="action" value="assign_rooms" />
          <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:14px;margin-bottom:12px;">
            <div class="form-group">
              <label class="form-label" for="assign_staff">Staff Member</label>
              <select class="form-select" id="assign_staff" name="admin_id" required>
                <option value="">— Select staff —</option>
                <?php foreach ($staffList as $staff): ?>
                  <option value="<?php echo (int)$staff['id']; ?>">
                    <?php echo htmlspecialchars($staff['full_name']); ?>
                    (<?php echo htmlspecialchars($staff['email']); ?>)
                  </option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label" for="room_from">Room From</label>
              <input class="form-input" type="text" id="room_from" name="room_from" placeholder="e.g. 100" required />
            </div>
            <div class="form-group">
              <label class="form-label" for="room_to">Room To</label>
              <input class="form-input" type="text" id="room_to" name="room_to" placeholder="e.g. 110" required />
            </div>
          </div>
          <p class="form-help" style="margin-bottom:14px;">Ranges cannot overlap.</p>
          <button type="submit" class="btn btn--primary btn--sm">Assign Range</button>
        </form>
      </div>
    </div>

    <!-- Assignments table -->
    <div class="card">
      <div class="table-wrap" style="border:none;border-radius:0;">
        <table aria-label="Room assignments">
          <thead>
            <tr>
              <th>Staff Name</th>
              <th>Email</th>
              <th>Room From</th>
              <th>Room To</th>
              <th>Remove</th>
            </tr>
          </thead>
          <tbody>
          <?php if (empty($assignments)): ?>
            <tr><td colspan="5" style="text-align:center;color:var(--text-muted);padding:32px;">No assignments yet.</td></tr>
          <?php else: ?>
            <?php foreach ($assignments as $asgn): ?>
            <tr>
              <td style="font-weight:500;"><?php echo htmlspecialchars($asgn['full_name']); ?></td>
              <td style="font-size:0.85rem;"><?php echo htmlspecialchars($asgn['email']); ?></td>
              <td><span class="mono" style="color:var(--forest);font-weight:600;"><?php echo htmlspecialchars($asgn['room_from']); ?></span></td>
              <td><span class="mono" style="color:var(--forest);font-weight:600;"><?php echo htmlspecialchars($asgn['room_to']); ?></span></td>
              <td>
                <form method="POST" action="admin_assignments.php"
                      onsubmit="return confirm('Remove assignment for <?php echo htmlspecialchars($asgn['full_name'], ENT_QUOTES); ?>?');">
                  <input type="hidden" name="action"        value="remove_assignment" />
                  <input type="hidden" name="assignment_id" value="<?php echo (int)$asgn['id']; ?>" />
                  <button type="submit" class="btn btn--danger btn--sm">Remove</button>
                </form>
              </td>
            </tr>
            <?php endforeach; ?>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

  </div><!-- /.admin-content -->
</div><!-- /.admin-layout -->

<script src="../../assets/js/main.js"></script>
<script>
// Live clock
function updateClock() {
  const el = document.getElementById('clock');
  if (el) el.textContent = new Date().toLocaleTimeString();
}
setInterval(updateClock, 1000);
updateClock();

// Auto-hide alerts after 4 seconds
setTimeout(() => {
  document.querySelectorAll('.alert').forEach(a => {
    a.style.transition = 'opacity 0.5s';
    a.style.opacity = '0';
    setTimeout(() => a.style.display = 'none', 500);
  });
}, 4000);
</script>
</body>
</html>
