<?php
/**
 * Wind Land Hotel — Staff Management
 * Self-contained. No header.php / footer.php.
 */

require_once '../../config/config.php';
require_once '../../config/Database.php';
require_once '../../classes/Admin.php';
require_once '../../classes/Room.php';
require_once '../../classes/RoomAssignment.php';
require_once '../../includes/admin_auth.php';

if ($admin_role !== 'super_admin') {
    header('Location: staff_dashboard.php');
    exit;
}

$adminObj  = new Admin();
$assignObj = new RoomAssignment();

/* ── POST handling (PRG) ───────────────────────────────── */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add_staff') {
        $full_name = trim($_POST['full_name'] ?? '');
        $email     = trim($_POST['email']     ?? '');
        $password  = $_POST['password'] ?? '';
        $hash      = password_hash($password, PASSWORD_DEFAULT);
        $adminObj->createStaff($full_name, $email, $hash);
        header('Location: admin_staff.php?success=staff_added');
        exit;
    }

    if ($action === 'delete_staff') {
        $staff_id = (int)($_POST['staff_id'] ?? 0);
        $adminObj->deleteStaff($staff_id);
        header('Location: admin_staff.php?success=staff_deleted');
        exit;
    }

    if ($action === 'toggle_staff') {
        $staff_id = (int)($_POST['staff_id'] ?? 0);
        $adminObj->toggleActive($staff_id);
        header('Location: admin_staff.php?success=staff_toggled');
        exit;
    }
}

/* ── Load data ─────────────────────────────────────────── */
$staffList   = $adminObj->getAllStaff();
$assignments = $assignObj->getAll();

/* ── Flash messages ────────────────────────────────────── */
$successMessages = [
    'staff_added'   => 'Staff created.',
    'staff_deleted' => 'Staff deleted.',
    'staff_toggled' => 'Staff status updated.',
];
$flashSuccess = isset($_GET['success']) ? ($successMessages[$_GET['success']] ?? '') : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Staff Management — Wind Land Hotel Admin</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400;1,600&family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="../../assets/css/style.css" />
  <style>
    .admin-topbar {
      position: fixed;
      top: 0; left: 0; right: 0;
      height: 60px;
      background: var(--ink);
      border-bottom: 1px solid rgba(184,150,62,0.2);
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 28px;
      z-index: 1000;
    }
    .admin-topbar__brand {
      font-family: var(--font-head);
      font-size: 1.2rem;
      font-weight: 600;
      color: var(--white);
      letter-spacing: 0.04em;
    }
    .admin-topbar__brand span {
      font-family: var(--font-mono);
      font-size: 0.62rem;
      color: var(--gold);
      letter-spacing: 0.14em;
      text-transform: uppercase;
      display: block;
      margin-top: 2px;
    }
    .admin-topbar__right {
      display: flex;
      align-items: center;
      gap: 16px;
    }
    .admin-topbar__user {
      font-size: 0.82rem;
      color: rgba(253,252,248,0.6);
    }
    .admin-topbar__user strong {
      color: var(--white);
      font-weight: 600;
    }
    .admin-layout {
      padding-top: 60px;
      min-height: 100vh;
      display: flex;
    }
    .admin-sidebar {
      width: 240px;
      background: var(--ink);
      border-right: 1px solid rgba(255,255,255,0.07);
      position: fixed;
      top: 60px;
      left: 0;
      bottom: 0;
      overflow-y: auto;
      padding: 20px 0 32px;
      z-index: 900;
    }
    .admin-content {
      margin-left: 240px;
      flex: 1;
      background: var(--paper);
      padding: 32px;
      min-height: calc(100vh - 60px);
    }
    @media (max-width: 768px) {
      .admin-sidebar { display: none; }
      .admin-content { margin-left: 0; padding: 20px 16px; }
    }
  </style>
</head>
<body>

<!-- TOP NAVBAR -->
<header class="admin-topbar">
  <div class="admin-topbar__brand">
    WindLand Hotel
    <span>Super Admin Panel</span>
  </div>
  <div class="admin-topbar__right">
    <div class="admin-topbar__user">
      Logged in as <strong><?php echo htmlspecialchars($_SESSION['admin_name']); ?></strong>
      &nbsp;<span class="badge badge--gold" style="font-size:0.62rem;">Super Admin</span>
    </div>
    <a href="logout.php" class="btn btn--danger btn--sm">Logout</a>
  </div>
</header>

<div class="admin-layout">

  <!-- SIDEBAR -->
  <aside class="admin-sidebar" role="navigation" aria-label="Admin navigation">
    <div class="admin-nav__section-label">Menu</div>

    <a href="admin_dashboard.php" class="admin-nav__link <?= basename($_SERVER['PHP_SELF'])==='admin_dashboard.php' ? 'active' : '' ?>">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
      Overview
    </a>
    <a href="admin_rooms.php" class="admin-nav__link <?= basename($_SERVER['PHP_SELF'])==='admin_rooms.php' ? 'active' : '' ?>">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
      Rooms
    </a>
    <a href="admin_staff.php" class="admin-nav__link <?= basename($_SERVER['PHP_SELF'])==='admin_staff.php' ? 'active' : '' ?>">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
      Staff
    </a>
    <a href="admin_assignments.php" class="admin-nav__link <?= basename($_SERVER['PHP_SELF'])==='admin_assignments.php' ? 'active' : '' ?>">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
      Assignments
    </a>

    <div class="admin-nav__section-label" style="margin-top:16px;">Clock</div>
    <div style="padding:6px 24px;font-family:var(--font-mono);font-size:0.72rem;color:rgba(253,252,248,0.3);">
      <span id="clock"></span>
    </div>
  </aside>

  <!-- MAIN CONTENT -->
  <div class="admin-content">

    <!-- Page heading -->
    <div class="flex-between" style="margin-bottom:20px;flex-wrap:wrap;gap:10px;">
      <h2 style="font-size:1.7rem;">Staff Accounts</h2>
      <button id="toggle-add-staff" class="btn btn--forest btn--sm" type="button">+ Add Staff</button>
    </div>

    <!-- Flash message -->
    <?php if ($flashSuccess): ?>
      <div class="alert alert--success" role="alert" style="margin-bottom:20px;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
        <?php echo htmlspecialchars($flashSuccess); ?>
      </div>
    <?php endif; ?>

    <!-- Add staff form (hidden by default) -->
    <div id="add-staff-form" style="display:none;margin-bottom:20px;">
      <div class="card">
        <div class="card__body">
          <h4 style="font-size:0.95rem;margin-bottom:16px;">New Staff Account</h4>
          <form method="POST" action="admin_staff.php">
            <input type="hidden" name="action" value="add_staff" />
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:14px;margin-bottom:16px;">
              <div class="form-group">
                <label class="form-label" for="full_name">Full Name</label>
                <input class="form-input" type="text" id="full_name" name="full_name" placeholder="e.g. Jean Bosco" required />
              </div>
              <div class="form-group">
                <label class="form-label" for="staff_email">Email</label>
                <input class="form-input" type="email" id="staff_email" name="email" placeholder="staff@windlandhotel.rw" required />
              </div>
              <div class="form-group">
                <label class="form-label" for="staff_password">Password</label>
                <div class="input-wrap">
                  <input class="form-input" type="password" id="staff_password" name="password" placeholder="Minimum 8 characters" required />
                  <button type="button" class="toggle-pw" aria-label="Show password">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                  </button>
                </div>
              </div>
            </div>
            <div style="display:flex;gap:10px;">
              <button type="submit" class="btn btn--primary btn--sm">Create Staff Account</button>
              <button type="button" id="cancel-add-staff" class="btn btn--ghost btn--sm">Cancel</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- Staff table -->
    <div class="card">
      <div class="table-wrap" style="border:none;border-radius:0;">
        <table aria-label="Staff accounts">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Status</th>
              <th>Assigned Range</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
          <?php if (empty($staffList)): ?>
            <tr><td colspan="5" style="text-align:center;color:var(--text-muted);padding:32px;">No staff accounts yet.</td></tr>
          <?php else: ?>
            <?php foreach ($staffList as $staff):
              // Find assignment for this staff member
              $staffAssignment = null;
              foreach ($assignments as $asgn) {
                  if ((int)$asgn['admin_id'] === (int)$staff['id']) {
                      $staffAssignment = $asgn;
                      break;
                  }
              }
              $isActive = (int)$staff['is_active'] === 1;
            ?>
            <tr>
              <td style="font-weight:500;"><?php echo htmlspecialchars($staff['full_name']); ?></td>
              <td style="font-size:0.85rem;"><?php echo htmlspecialchars($staff['email']); ?></td>
              <td>
                <span class="badge <?php echo $isActive ? 'badge--green' : 'badge--gray'; ?>">
                  <?php echo $isActive ? 'Active' : 'Inactive'; ?>
                </span>
              </td>
              <td>
                <?php if ($staffAssignment): ?>
                  <span class="mono" style="background:rgba(42,92,63,0.08);color:var(--forest);border:1px solid rgba(42,92,63,0.2);padding:3px 10px;border-radius:100px;font-size:0.8rem;">
                    <?php echo htmlspecialchars($staffAssignment['room_from']); ?> &rarr;
                    <?php echo htmlspecialchars($staffAssignment['room_to']); ?>
                  </span>
                <?php else: ?>
                  <span class="text-muted" style="font-size:0.82rem;">Not assigned</span>
                <?php endif; ?>
              </td>
              <td>
                <div style="display:flex;gap:8px;flex-wrap:wrap;">
                  <form method="POST" action="admin_staff.php">
                    <input type="hidden" name="action"   value="toggle_staff" />
                    <input type="hidden" name="staff_id" value="<?php echo (int)$staff['id']; ?>" />
                    <button type="submit" class="btn btn--sm <?php echo $isActive ? 'btn--ghost' : 'btn--forest'; ?>">
                      <?php echo $isActive ? 'Deactivate' : 'Activate'; ?>
                    </button>
                  </form>
                  <form method="POST" action="admin_staff.php"
                        onsubmit="return confirm('Delete staff account for <?php echo htmlspecialchars($staff['full_name'], ENT_QUOTES); ?>?');">
                    <input type="hidden" name="action"   value="delete_staff" />
                    <input type="hidden" name="staff_id" value="<?php echo (int)$staff['id']; ?>" />
                    <button type="submit" class="btn btn--danger btn--sm">Delete</button>
                  </form>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

  </div><!-- /.admin-content -->
</div><!-- /.admin-layout -->

<script src="../../assets/js/main.js"></script>
<script>
// Live clock
function updateClock() {
  const el = document.getElementById('clock');
  if (el) el.textContent = new Date().toLocaleTimeString();
}
setInterval(updateClock, 1000);
updateClock();

// Auto-hide alerts after 4 seconds
setTimeout(() => {
  document.querySelectorAll('.alert').forEach(a => {
    a.style.transition = 'opacity 0.5s';
    a.style.opacity = '0';
    setTimeout(() => a.style.display = 'none', 500);
  });
}, 4000);

// Toggle add-staff form
document.getElementById('toggle-add-staff')?.addEventListener('click', () => {
  const f = document.getElementById('add-staff-form');
  f.style.display = f.style.display === 'none' ? 'block' : 'none';
});
document.getElementById('cancel-add-staff')?.addEventListener('click', () => {
  document.getElementById('add-staff-form').style.display = 'none';
});

// Password show/hide toggle
document.querySelector('.toggle-pw')?.addEventListener('click', function () {
  const input = document.getElementById('staff_password');
  if (!input) return;
  input.type = input.type === 'password' ? 'text' : 'password';
});
</script>
</body>
</html>
