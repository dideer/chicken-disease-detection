<?php
/**
 * Wind Land Hotel — Rooms Management
 * Self-contained. No header.php / footer.php.
 */

require_once '../../config/config.php';
require_once '../../config/Database.php';
require_once '../../classes/Admin.php';
require_once '../../classes/Room.php';
require_once '../../classes/RoomAssignment.php';
require_once '../../includes/admin_auth.php';

if ($admin_role !== 'super_admin') {
    header('Location: staff_dashboard.php');
    exit;
}

$roomObj = new Room();

/* ── POST handling (PRG) ───────────────────────────────── */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add_room') {
        $room_number = trim($_POST['room_number'] ?? '');
        $floor       = (int)($_POST['floor'] ?? 1);
        $type        = $_POST['type'] ?? 'single';
        $price       = (float)($_POST['price'] ?? 0);
        $roomObj->create($room_number, $floor, $type, $price);
        header('Location: admin_rooms.php?success=room_added');
        exit;
    }

    if ($action === 'delete_room') {
        $room_id = (int)($_POST['room_id'] ?? 0);
        $roomObj->delete($room_id);
        header('Location: admin_rooms.php?success=room_deleted');
        exit;
    }

    if ($action === 'update_status') {
        $room_id = (int)($_POST['room_id'] ?? 0);
        $status  = $_POST['status'] ?? '';
        $roomObj->updateStatus($room_id, $status);
        header('Location: admin_rooms.php?success=status_updated');
        exit;
    }
}

/* ── Load data ─────────────────────────────────────────── */
$rooms = $roomObj->getAll();

/* ── Flash messages ────────────────────────────────────── */
$successMessages = [
    'room_added'     => 'Room added.',
    'room_deleted'   => 'Room deleted.',
    'status_updated' => 'Status updated.',
];
$flashSuccess = isset($_GET['success']) ? ($successMessages[$_GET['success']] ?? '') : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Rooms Management — Wind Land Hotel Admin</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400;1,600&family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="../../assets/css/style.css" />
  <style>
    .admin-topbar {
      position: fixed;
      top: 0; left: 0; right: 0;
      height: 60px;
      background: var(--ink);
      border-bottom: 1px solid rgba(184,150,62,0.2);
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 28px;
      z-index: 1000;
    }
    .admin-topbar__brand {
      font-family: var(--font-head);
      font-size: 1.2rem;
      font-weight: 600;
      color: var(--white);
      letter-spacing: 0.04em;
    }
    .admin-topbar__brand span {
      font-family: var(--font-mono);
      font-size: 0.62rem;
      color: var(--gold);
      letter-spacing: 0.14em;
      text-transform: uppercase;
      display: block;
      margin-top: 2px;
    }
    .admin-topbar__right {
      display: flex;
      align-items: center;
      gap: 16px;
    }
    .admin-topbar__user {
      font-size: 0.82rem;
      color: rgba(253,252,248,0.6);
    }
    .admin-topbar__user strong {
      color: var(--white);
      font-weight: 600;
    }
    .admin-layout {
      padding-top: 60px;
      min-height: 100vh;
      display: flex;
    }
    .admin-sidebar {
      width: 240px;
      background: var(--ink);
      border-right: 1px solid rgba(255,255,255,0.07);
      position: fixed;
      top: 60px;
      left: 0;
      bottom: 0;
      overflow-y: auto;
      padding: 20px 0 32px;
      z-index: 900;
    }
    .admin-content {
      margin-left: 240px;
      flex: 1;
      background: var(--paper);
      padding: 32px;
      min-height: calc(100vh - 60px);
    }
    @media (max-width: 768px) {
      .admin-sidebar { display: none; }
      .admin-content { margin-left: 0; padding: 20px 16px; }
    }
  </style>
</head>
<body>

<!-- TOP NAVBAR -->
<header class="admin-topbar">
  <div class="admin-topbar__brand">
    WindLand Hotel
    <span>Super Admin Panel</span>
  </div>
  <div class="admin-topbar__right">
    <div class="admin-topbar__user">
      Logged in as <strong><?php echo htmlspecialchars($_SESSION['admin_name']); ?></strong>
      &nbsp;<span class="badge badge--gold" style="font-size:0.62rem;">Super Admin</span>
    </div>
    <a href="logout.php" class="btn btn--danger btn--sm">Logout</a>
  </div>
</header>

<div class="admin-layout">

  <!-- SIDEBAR -->
  <aside class="admin-sidebar" role="navigation" aria-label="Admin navigation">
    <div class="admin-nav__section-label">Menu</div>

    <a href="admin_dashboard.php" class="admin-nav__link <?= basename($_SERVER['PHP_SELF'])==='admin_dashboard.php' ? 'active' : '' ?>">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
      Overview
    </a>
    <a href="admin_rooms.php" class="admin-nav__link <?= basename($_SERVER['PHP_SELF'])==='admin_rooms.php' ? 'active' : '' ?>">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
      Rooms
    </a>
    <a href="admin_staff.php" class="admin-nav__link <?= basename($_SERVER['PHP_SELF'])==='admin_staff.php' ? 'active' : '' ?>">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
      Staff
    </a>
    <a href="admin_assignments.php" class="admin-nav__link <?= basename($_SERVER['PHP_SELF'])==='admin_assignments.php' ? 'active' : '' ?>">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
      Assignments
    </a>

    <div class="admin-nav__section-label" style="margin-top:16px;">Clock</div>
    <div style="padding:6px 24px;font-family:var(--font-mono);font-size:0.72rem;color:rgba(253,252,248,0.3);">
      <span id="clock"></span>
    </div>
  </aside>

  <!-- MAIN CONTENT -->
  <div class="admin-content">

    <!-- Page heading -->
    <div class="flex-between" style="margin-bottom:20px;flex-wrap:wrap;gap:10px;">
      <h2 style="font-size:1.7rem;">Rooms Management</h2>
      <button id="toggle-add-room" class="btn btn--forest btn--sm" type="button">+ Add New Room</button>
    </div>

    <!-- Flash message -->
    <?php if ($flashSuccess): ?>
      <div class="alert alert--success" role="alert" style="margin-bottom:20px;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
        <?php echo htmlspecialchars($flashSuccess); ?>
      </div>
    <?php endif; ?>

    <!-- Add room form (hidden by default) -->
    <div id="add-room-form" style="display:none;margin-bottom:20px;">
      <div class="card">
        <div class="card__body">
          <h4 style="font-size:0.95rem;margin-bottom:16px;">New Room Details</h4>
          <form method="POST" action="admin_rooms.php">
            <input type="hidden" name="action" value="add_room" />
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:14px;margin-bottom:16px;">
              <div class="form-group">
                <label class="form-label" for="room_number">Room Number</label>
                <input class="form-input" type="text" id="room_number" name="room_number" placeholder="e.g. 105" required />
              </div>
              <div class="form-group">
                <label class="form-label" for="floor">Floor</label>
                <input class="form-input" type="number" id="floor" name="floor" min="1" placeholder="1" required />
              </div>
              <div class="form-group">
                <label class="form-label" for="type">Type</label>
                <select class="form-select" id="type" name="type">
                  <option value="single">Single</option>
                  <option value="double">Double</option>
                  <option value="suite">Suite</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label" for="price">Price / Night ($)</label>
                <input class="form-input" type="number" id="price" name="price" step="0.01" min="0" placeholder="89.00" required />
              </div>
            </div>
            <div style="display:flex;gap:10px;">
              <button type="submit" class="btn btn--primary btn--sm">Add Room</button>
              <button type="button" id="cancel-add-room" class="btn btn--ghost btn--sm">Cancel</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- Rooms table -->
    <div class="card">
      <div class="table-wrap" style="border:none;border-radius:0;">
        <table aria-label="All rooms">
          <thead>
            <tr>
              <th>Room No</th>
              <th>Floor</th>
              <th>Type</th>
              <th>Price</th>
              <th>Status</th>
              <th>Change Status</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
          <?php if (empty($rooms)): ?>
            <tr><td colspan="7" style="text-align:center;color:var(--text-muted);padding:32px;">No rooms found. Add one above.</td></tr>
          <?php else: ?>
            <?php foreach ($rooms as $room):
              $statusBadge = match($room['status']) {
                  'occupied'    => 'badge--red',
                  'maintenance' => 'badge--gold',
                  default       => 'badge--green',
              };
            ?>
            <tr>
              <td><span class="room-number-badge"><?php echo htmlspecialchars($room['room_number']); ?></span></td>
              <td>Floor <?php echo (int)$room['floor']; ?></td>
              <td><?php echo ucfirst(htmlspecialchars($room['type'])); ?></td>
              <td><span class="mono">$<?php echo number_format((float)$room['price'], 2); ?>/night</span></td>
              <td><span class="badge <?php echo $statusBadge; ?>"><?php echo ucfirst($room['status']); ?></span></td>
              <td>
                <?php if ($room['status'] !== 'occupied'): ?>
                <form method="POST" action="admin_rooms.php" style="display:flex;gap:6px;align-items:center;">
                  <input type="hidden" name="action"  value="update_status" />
                  <input type="hidden" name="room_id" value="<?php echo (int)$room['id']; ?>" />
                  <select class="form-select" name="status" style="padding:5px 8px;font-size:0.8rem;width:auto;">
                    <option value="available"   <?php echo $room['status']==='available'   ? 'selected' : ''; ?>>Available</option>
                    <option value="maintenance" <?php echo $room['status']==='maintenance' ? 'selected' : ''; ?>>Maintenance</option>
                  </select>
                  <button type="submit" class="btn btn--ghost btn--sm">Update</button>
                </form>
                <?php else: ?>
                  <span class="text-muted" style="font-size:0.82rem;">Guest inside</span>
                <?php endif; ?>
              </td>
              <td>
                <?php if ($room['status'] !== 'occupied'): ?>
                <form method="POST" action="admin_rooms.php"
                      onsubmit="return confirm('Delete room <?php echo htmlspecialchars($room['room_number'], ENT_QUOTES); ?>?');">
                  <input type="hidden" name="action"  value="delete_room" />
                  <input type="hidden" name="room_id" value="<?php echo (int)$room['id']; ?>" />
                  <button type="submit" class="btn btn--danger btn--sm">Delete</button>
                </form>
                <?php else: ?>
                  <span class="text-muted" style="font-size:0.82rem;">—</span>
                <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; ?>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

  </div><!-- /.admin-content -->
</div><!-- /.admin-layout -->

<script src="../../assets/js/main.js"></script>
<script>
// Live clock
function updateClock() {
  const el = document.getElementById('clock');
  if (el) el.textContent = new Date().toLocaleTimeString();
}
setInterval(updateClock, 1000);
updateClock();

// Auto-hide alerts after 4 seconds
setTimeout(() => {
  document.querySelectorAll('.alert').forEach(a => {
    a.style.transition = 'opacity 0.5s';
    a.style.opacity = '0';
    setTimeout(() => a.style.display = 'none', 500);
  });
}, 4000);

// Toggle add-room form
document.getElementById('toggle-add-room')?.addEventListener('click', () => {
  const f = document.getElementById('add-room-form');
  f.style.display = f.style.display === 'none' ? 'block' : 'none';
});
document.getElementById('cancel-add-room')?.addEventListener('click', () => {
  document.getElementById('add-room-form').style.display = 'none';
});
</script>
</body>
</html>
