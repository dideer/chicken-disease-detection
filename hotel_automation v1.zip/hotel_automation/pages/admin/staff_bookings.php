<?php
require_once '../../includes/staff_bootstrap.php';
$pageTitle = 'Bookings';
include '../../includes/staff_layout.php';
?>

    <!-- Page heading -->
    <div style="margin-bottom:20px;">
      <h2 style="font-size:1.7rem;">Room Bookings</h2>
      <p style="font-size:0.85rem;color:var(--text-muted);margin-top:4px;">
        All bookings for your assigned rooms
        <?php if ($assignment): ?>
          <span class="badge badge--green" style="margin-left:6px;">
            <?php echo htmlspecialchars($assignment['room_from']); ?> &ndash; <?php echo htmlspecialchars($assignment['room_to']); ?>
          </span>
        <?php endif; ?>
      </p>
    </div>

    <!-- Flash messages -->
    <?php if ($flashSuccess): ?>
      <div class="alert alert--success" role="alert" style="margin-bottom:20px;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
        <?php echo htmlspecialchars($flashSuccess); ?>
      </div>
    <?php endif; ?>
    <?php if ($flashError): ?>
      <div class="alert alert--error" role="alert" style="margin-bottom:20px;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <?php echo htmlspecialchars($flashError); ?>
      </div>
    <?php endif; ?>

    <?php if ($noAssignment): ?>
      <div class="alert alert--warning" role="alert" style="padding:20px 22px;">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0;"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
        <div>
          <strong>You have no rooms assigned yet.</strong><br>
          <span style="font-size:0.85rem;">Please contact your Super Admin to assign a room range to your account.</span>
        </div>
      </div>
    <?php elseif (empty($bookings)): ?>
      <div class="empty-state">
        <div class="empty-state__icon">📋</div>
        <h4>No bookings found</h4>
        <p>No bookings have been made for your assigned rooms yet.</p>
      </div>
    <?php else: ?>

      <!-- Summary pills -->
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px;">
        <span class="badge badge--green">Active: <?php echo $activeBookings; ?></span>
        <span class="badge badge--gray">Checked Out: <?php echo count(array_filter($bookings, fn($b) => $b['status']==='checked_out')); ?></span>
        <span class="badge badge--red">Cancelled: <?php echo count(array_filter($bookings, fn($b) => $b['status']==='cancelled')); ?></span>
      </div>

      <div class="card">
        <div class="table-wrap" style="border:none;border-radius:0;">
          <table aria-label="Room bookings">
            <thead>
              <tr>
                <th>Booking ID</th>
                <th>Guest</th>
                <th>Room</th>
                <th>Check-in</th>
                <th>Check-out</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
            <?php foreach ($bookings as $b):
              $bBadge = match($b['status']) {
                  'active'      => 'badge--green',
                  'checked_out' => 'badge--gray',
                  'cancelled'   => 'badge--red',
                  default       => 'badge--gray',
              };
              $bLabel = match($b['status']) {
                  'active'      => 'Active',
                  'checked_out' => 'Checked Out',
                  'cancelled'   => 'Cancelled',
                  default       => ucfirst($b['status']),
              };
              $bookingRoom = null;
              foreach ($assignedRooms as $r) {
                  if ((int)$r['id'] === (int)$b['room_id']) { $bookingRoom = $r; break; }
              }
            ?>
              <tr>
                <td><span class="mono" style="font-size:0.82rem;color:var(--text-muted);">#<?php echo (int)$b['id']; ?></span></td>
                <td>
                  <div style="font-weight:500;font-size:0.88rem;"><?php echo htmlspecialchars($b['full_name']); ?></div>
                  <div style="font-size:0.75rem;color:var(--text-muted);"><?php echo htmlspecialchars($b['email']); ?></div>
                </td>
                <td>
                  <?php if ($bookingRoom): ?>
                    <span class="room-number-badge"><?php echo htmlspecialchars($bookingRoom['room_number']); ?></span>
                  <?php else: ?>
                    <span class="mono"><?php echo (int)$b['room_id']; ?></span>
                  <?php endif; ?>
                </td>
                <td style="font-size:0.85rem;"><?php echo date('d M Y', strtotime($b['check_in'])); ?></td>
                <td style="font-size:0.85rem;"><?php echo date('d M Y', strtotime($b['check_out'])); ?></td>
                <td><span class="badge <?php echo $bBadge; ?>"><?php echo $bLabel; ?></span></td>
                <td>
                  <?php if ($b['status'] === 'active'): ?>
                    <div style="display:flex;gap:8px;flex-wrap:wrap;">
                      <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>"
                            onsubmit="return confirm('Cancel this booking? Room will be freed.');">
                        <input type="hidden" name="action"     value="cancel_booking" />
                        <input type="hidden" name="booking_id" value="<?php echo (int)$b['id']; ?>" />
                        <button type="submit" class="btn btn--danger btn--sm">Cancel</button>
                      </form>
                      <span style="font-size:0.75rem;color:var(--text-muted);align-self:center;">
                        Auto-checkout on <?php echo date('d M Y', strtotime($b['check_out'])); ?>
                      </span>
                    </div>
                  <?php else: ?>
                    <span style="color:var(--text-muted);font-size:0.85rem;">—</span>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>

    <?php endif; ?>

<?php include '../../includes/staff_layout_end.php'; ?>
