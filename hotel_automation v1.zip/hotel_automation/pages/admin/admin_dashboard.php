<?php
/**
 * Wind Land Hotel — Super Admin Dashboard (Overview)
 * Self-contained. No header.php / footer.php.
 */

require_once '../../config/config.php';
require_once '../../config/Database.php';
require_once '../../classes/Admin.php';
require_once '../../classes/Room.php';
require_once '../../classes/RoomAssignment.php';
require_once '../../includes/admin_auth.php';

if ($admin_role !== 'super_admin') {
    header('Location: staff_dashboard.php');
    exit;
}

$adminObj  = new Admin();
$roomObj   = new Room();
$assignObj = new RoomAssignment();

/* ── Load data ─────────────────────────────────────────── */
$rooms       = $roomObj->getAll();
$staffList   = $adminObj->getAllStaff();
$assignments = $assignObj->getAll();

$total       = count($rooms);
$occupied    = count(array_filter($rooms, fn($r) => $r['status'] === 'occupied'));
$available   = count(array_filter($rooms, fn($r) => $r['status'] === 'available'));
$maintenance = count(array_filter($rooms, fn($r) => $r['status'] === 'maintenance'));
$totalStaff  = count($staffList);

/* ── Greeting ──────────────────────────────────────────── */
$hour     = (int)date('G');
$greeting = $hour < 12 ? 'Good morning' : ($hour < 17 ? 'Good afternoon' : 'Good evening');

/* ── Flash messages ────────────────────────────────────── */
$successMessages = [
    'room_added'         => 'Room added.',
    'room_deleted'       => 'Room deleted.',
    'status_updated'     => 'Status updated.',
    'staff_added'        => 'Staff created.',
    'staff_deleted'      => 'Staff deleted.',
    'staff_toggled'      => 'Staff status updated.',
    'rooms_assigned'     => 'Room range assigned.',
    'assignment_removed' => 'Assignment removed.',
];
$errorMessages = [
    'range_overlap' => 'Room range overlaps existing assignment.',
];
$flashSuccess = isset($_GET['success']) ? ($successMessages[$_GET['success']] ?? '') : '';
$flashError   = isset($_GET['error'])   ? ($errorMessages[$_GET['error']]     ?? '') : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Overview — Wind Land Hotel Admin</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400;1,600&family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="../../assets/css/style.css" />
  <style>
    .admin-topbar {
      position: fixed;
      top: 0; left: 0; right: 0;
      height: 60px;
      background: var(--ink);
      border-bottom: 1px solid rgba(184,150,62,0.2);
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 28px;
      z-index: 1000;
    }
    .admin-topbar__brand {
      font-family: var(--font-head);
      font-size: 1.2rem;
      font-weight: 600;
      color: var(--white);
      letter-spacing: 0.04em;
    }
    .admin-topbar__brand span {
      font-family: var(--font-mono);
      font-size: 0.62rem;
      color: var(--gold);
      letter-spacing: 0.14em;
      text-transform: uppercase;
      display: block;
      margin-top: 2px;
    }
    .admin-topbar__right {
      display: flex;
      align-items: center;
      gap: 16px;
    }
    .admin-topbar__user {
      font-size: 0.82rem;
      color: rgba(253,252,248,0.6);
    }
    .admin-topbar__user strong {
      color: var(--white);
      font-weight: 600;
    }
    .admin-layout {
      padding-top: 60px;
      min-height: 100vh;
      display: flex;
    }
    .admin-sidebar {
      width: 240px;
      background: var(--ink);
      border-right: 1px solid rgba(255,255,255,0.07);
      position: fixed;
      top: 60px;
      left: 0;
      bottom: 0;
      overflow-y: auto;
      padding: 20px 0 32px;
      z-index: 900;
    }
    .admin-content {
      margin-left: 240px;
      flex: 1;
      background: var(--paper);
      padding: 32px;
      min-height: calc(100vh - 60px);
    }
    /* Summary cards */
    .summary-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
      gap: 20px;
      margin-top: 28px;
    }
    .summary-card {
      background: var(--white);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 24px;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .summary-card__title {
      font-family: var(--font-mono);
      font-size: 0.68rem;
      letter-spacing: 0.14em;
      text-transform: uppercase;
      color: var(--gold);
    }
    .summary-card__stat {
      font-family: var(--font-head);
      font-size: 2rem;
      font-weight: 600;
      color: var(--forest);
      line-height: 1;
    }
    .summary-card__desc {
      font-size: 0.82rem;
      color: var(--text-muted);
    }

    /* ══════════════════════════════════════════════════
       RESPONSIVE BREAKPOINTS
       ══════════════════════════════════════════════════ */

    /* Tablet: 769px – 1024px */
    @media (max-width: 1024px) {
      .admin-sidebar {
        width: 200px;
      }
      .admin-content {
        margin-left: 200px;
        padding: 24px;
      }
      .summary-grid {
        grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
        gap: 16px;
      }
    }

    /* Mobile & Small Tablet: max-width 768px */
    @media (max-width: 768px) {
      #sidebar-toggle {
        display: flex !important;
      }
      .admin-topbar {
        padding: 0 16px;
        height: 56px;
      }
      .admin-topbar__brand {
        font-size: 1rem;
      }
      .admin-topbar__brand span {
        font-size: 0.58rem;
      }
      .admin-topbar__user {
        display: none;
      }
      .admin-topbar__right {
        gap: 10px;
      }
      .admin-layout {
        padding-top: 56px;
      }
      .admin-sidebar {
        transform: translateX(-100%);
        transition: transform 0.28s cubic-bezier(0.4,0,0.2,1);
        display: block !important; /* override previous display:none */
        width: 240px;
      }
      .admin-sidebar.open {
        transform: translateX(0);
      }
      .admin-content {
        margin-left: 0;
        padding: 20px 16px;
      }
      .admin-content h2 {
        font-size: 1.4rem !important;
      }
      .dash-stats {
        grid-template-columns: repeat(2, 1fr) !important;
        gap: 12px !important;
      }
      .dash-stat {
        padding: 18px !important;
      }
      .dash-stat__value {
        font-size: 2rem !important;
      }
      .summary-grid {
        grid-template-columns: 1fr;
        gap: 14px;
        margin-top: 20px;
      }
      .summary-card {
        padding: 20px;
      }
      .summary-card__stat {
        font-size: 1.8rem;
      }
    }

    /* Extra small phones: max-width 480px */
    @media (max-width: 480px) {
      .admin-topbar {
        padding: 0 12px;
      }
      .admin-topbar__brand {
        font-size: 0.9rem;
      }
      .admin-topbar__brand span {
        font-size: 0.52rem;
        margin-top: 1px;
      }
      .admin-content {
        padding: 16px 12px;
      }
      .admin-content h2 {
        font-size: 1.2rem !important;
      }
      .admin-content p {
        font-size: 0.78rem !important;
      }
      .dash-stats {
        grid-template-columns: 1fr !important;
        gap: 10px !important;
      }
      .dash-stat {
        padding: 16px !important;
      }
      .dash-stat__label {
        font-size: 0.7rem !important;
      }
      .dash-stat__value {
        font-size: 1.8rem !important;
      }
      .dash-stat__sub {
        font-size: 0.72rem !important;
      }
      .summary-card {
        padding: 18px;
      }
      .summary-card__stat {
        font-size: 1.6rem;
      }
      .summary-card__desc {
        font-size: 0.78rem;
      }
      .btn--sm {
        padding: 7px 16px !important;
        font-size: 0.75rem !important;
      }
      .alert {
        padding: 12px 14px !important;
        font-size: 0.82rem !important;
      }
    }
  </style>
</head>
<body>

<!-- TOP NAVBAR -->
<header class="admin-topbar">
  <div style="display:flex;align-items:center;gap:14px;">
    <!-- Hamburger — mobile only -->
    <button id="sidebar-toggle" aria-label="Toggle navigation" style="
      display:none;
      flex-direction:column;
      gap:5px;
      padding:6px;
      background:none;
      border:none;
      cursor:pointer;
      border-radius:6px;
    ">
      <span style="display:block;width:20px;height:2px;background:var(--white);border-radius:2px;transition:all 0.25s;"></span>
      <span style="display:block;width:20px;height:2px;background:var(--white);border-radius:2px;transition:all 0.25s;"></span>
      <span style="display:block;width:20px;height:2px;background:var(--white);border-radius:2px;transition:all 0.25s;"></span>
    </button>
    <div class="admin-topbar__brand">
      WindLand Hotel
      <span>Super Admin Panel</span>
    </div>
  </div>
  <div class="admin-topbar__right">
    <div class="admin-topbar__user">
      Logged in as <strong><?php echo htmlspecialchars($_SESSION['admin_name']); ?></strong>
      &nbsp;<span class="badge badge--gold" style="font-size:0.62rem;">Super Admin</span>
    </div>
    <a href="logout.php" class="btn btn--danger btn--sm">Logout</a>
  </div>
</header>

<!-- Mobile sidebar overlay -->
<div id="sidebar-overlay" style="
  display:none;
  position:fixed;
  inset:0;
  background:rgba(0,0,0,0.55);
  z-index:850;
  backdrop-filter:blur(2px);
"></div>

<div class="admin-layout">

  <!-- SIDEBAR -->
  <aside class="admin-sidebar" role="navigation" aria-label="Admin navigation">
    <div class="admin-nav__section-label">Menu</div>

    <a href="admin_dashboard.php" class="admin-nav__link <?= basename($_SERVER['PHP_SELF'])==='admin_dashboard.php' ? 'active' : '' ?>">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
      Overview
    </a>
    <a href="admin_rooms.php" class="admin-nav__link <?= basename($_SERVER['PHP_SELF'])==='admin_rooms.php' ? 'active' : '' ?>">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
      Rooms
    </a>
    <a href="admin_staff.php" class="admin-nav__link <?= basename($_SERVER['PHP_SELF'])==='admin_staff.php' ? 'active' : '' ?>">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
      Staff
    </a>
    <a href="admin_assignments.php" class="admin-nav__link <?= basename($_SERVER['PHP_SELF'])==='admin_assignments.php' ? 'active' : '' ?>">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
      Assignments
    </a>

    <div class="admin-nav__section-label" style="margin-top:16px;">Clock</div>
    <div style="padding:6px 24px;font-family:var(--font-mono);font-size:0.72rem;color:rgba(253,252,248,0.3);">
      <span id="clock"></span>
    </div>
  </aside>

  <!-- MAIN CONTENT -->
  <div class="admin-content">

    <!-- Page heading -->
    <div class="flex-between" style="margin-bottom:20px;flex-wrap:wrap;gap:12px;">
      <div>
        <h2 style="font-size:1.7rem;"><?php echo $greeting; ?>, <?php echo htmlspecialchars($_SESSION['admin_name']); ?></h2>
        <p style="font-size:0.85rem;color:var(--text-muted);"><?php echo date('l, d F Y'); ?></p>
      </div>
    </div>

    <!-- Flash messages -->
    <?php if ($flashSuccess): ?>
      <div class="alert alert--success" role="alert" style="margin-bottom:20px;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
        <?php echo htmlspecialchars($flashSuccess); ?>
      </div>
    <?php endif; ?>
    <?php if ($flashError): ?>
      <div class="alert alert--error" role="alert" style="margin-bottom:20px;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <?php echo htmlspecialchars($flashError); ?>
      </div>
    <?php endif; ?>

    <!-- Stats bar -->
    <div class="dash-stats">
      <div class="dash-stat">
        <div class="dash-stat__label">Total Rooms</div>
        <div class="dash-stat__value"><?php echo $total; ?></div>
        <div class="dash-stat__sub">All rooms</div>
      </div>
      <div class="dash-stat">
        <div class="dash-stat__label">Occupied</div>
        <div class="dash-stat__value" style="color:var(--error);"><?php echo $occupied; ?></div>
        <div class="dash-stat__sub">Active guests</div>
      </div>
      <div class="dash-stat">
        <div class="dash-stat__label">Available</div>
        <div class="dash-stat__value" style="color:var(--forest);"><?php echo $available; ?></div>
        <div class="dash-stat__sub">Ready to book</div>
      </div>
      <div class="dash-stat">
        <div class="dash-stat__label">Maintenance</div>
        <div class="dash-stat__value" style="color:var(--gold);"><?php echo $maintenance; ?></div>
        <div class="dash-stat__sub">Under service</div>
      </div>
      <div class="dash-stat">
        <div class="dash-stat__label">Total Staff</div>
        <div class="dash-stat__value"><?php echo $totalStaff; ?></div>
        <div class="dash-stat__sub">Staff accounts</div>
      </div>
    </div>

    <!-- Section summary cards -->
    <div class="summary-grid">

      <!-- Rooms card -->
      <div class="summary-card">
        <div class="summary-card__title">Rooms</div>
        <div class="summary-card__stat"><?php echo $total; ?></div>
        <div class="summary-card__desc"><?php echo $available; ?> available &middot; <?php echo $occupied; ?> occupied &middot; <?php echo $maintenance; ?> maintenance</div>
        <div style="margin-top:6px;">
          <a href="admin_rooms.php" class="btn btn--forest btn--sm">Manage Rooms</a>
        </div>
      </div>

      <!-- Staff card -->
      <div class="summary-card">
        <div class="summary-card__title">Staff</div>
        <div class="summary-card__stat"><?php echo $totalStaff; ?></div>
        <div class="summary-card__desc"><?php echo $totalStaff; ?> staff account<?php echo $totalStaff !== 1 ? 's' : ''; ?> registered</div>
        <div style="margin-top:6px;">
          <a href="admin_staff.php" class="btn btn--forest btn--sm">Manage Staff</a>
        </div>
      </div>

      <!-- Assignments card -->
      <div class="summary-card">
        <div class="summary-card__title">Assignments</div>
        <div class="summary-card__stat"><?php echo count($assignments); ?></div>
        <div class="summary-card__desc"><?php echo count($assignments); ?> room range<?php echo count($assignments) !== 1 ? 's' : ''; ?> assigned to staff</div>
        <div style="margin-top:6px;">
          <a href="admin_assignments.php" class="btn btn--forest btn--sm">View Assignments</a>
        </div>
      </div>

    </div>

  </div><!-- /.admin-content -->
</div><!-- /.admin-layout -->

<script src="../../assets/js/main.js"></script>
<script>
// Live clock
function updateClock() {
  const el = document.getElementById('clock');
  if (el) el.textContent = new Date().toLocaleTimeString();
}
setInterval(updateClock, 1000);
updateClock();

// Auto-hide alerts after 4 seconds
setTimeout(() => {
  document.querySelectorAll('.alert').forEach(a => {
    a.style.transition = 'opacity 0.5s';
    a.style.opacity = '0';
    setTimeout(() => a.style.display = 'none', 500);
  });
}, 4000);

// ── Mobile sidebar toggle ──────────────────────────────
const sidebarToggle  = document.getElementById('sidebar-toggle');
const sidebar        = document.querySelector('.admin-sidebar');
const sidebarOverlay = document.getElementById('sidebar-overlay');

function openSidebar() {
  sidebar.classList.add('open');
  sidebarOverlay.style.display = 'block';
  document.body.style.overflow = 'hidden';
  sidebarToggle.setAttribute('aria-expanded', 'true');
}
function closeSidebar() {
  sidebar.classList.remove('open');
  sidebarOverlay.style.display = 'none';
  document.body.style.overflow = '';
  sidebarToggle.setAttribute('aria-expanded', 'false');
}

sidebarToggle?.addEventListener('click', () => {
  sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
});

// Close when clicking overlay
sidebarOverlay?.addEventListener('click', closeSidebar);

// Close when a nav link is clicked on mobile
document.querySelectorAll('.admin-nav__link').forEach(link => {
  link.addEventListener('click', () => {
    if (window.innerWidth <= 768) closeSidebar();
  });
});

// Close sidebar if window resizes to desktop
window.addEventListener('resize', () => {
  if (window.innerWidth > 768) closeSidebar();
});
</script>
</body>
</html>
