<?php
require_once '../../includes/staff_bootstrap.php';
$pageTitle = 'Dashboard Overview';
include '../../includes/staff_layout.php';
?>

    <!-- Welcome bar -->
    <div class="flex-between" style="margin-bottom:24px;flex-wrap:wrap;gap:12px;">
      <div>
        <h2 style="font-size:1.7rem;"><?php echo $greeting; ?>, <?php echo htmlspecialchars($_SESSION['admin_name']); ?></h2>
        <p style="font-size:0.85rem;color:var(--text-muted);"><?php echo date('l, d F Y'); ?></p>
      </div>
      <span style="font-family:var(--font-mono);font-size:0.72rem;color:var(--text-muted);">Auto-refreshes every 30s</span>
    </div>

    <!-- Flash messages -->
    <?php if ($flashSuccess): ?>
      <div class="alert alert--success" role="alert" style="margin-bottom:20px;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
        <?php echo htmlspecialchars($flashSuccess); ?>
      </div>
    <?php endif; ?>
    <?php if ($flashError): ?>
      <div class="alert alert--error" role="alert" style="margin-bottom:20px;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <?php echo htmlspecialchars($flashError); ?>
      </div>
    <?php endif; ?>

    <?php if ($noAssignment): ?>
      <!-- No assignment notice -->
      <div class="alert alert--warning" role="alert" style="padding:20px 22px;">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0;"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
        <div>
          <strong>You have no rooms assigned yet.</strong><br>
          <span style="font-size:0.85rem;">Please contact your Super Admin to assign a room range to your account.</span>
        </div>
      </div>
    <?php else: ?>

      <!-- Stats bar -->
      <div class="dash-stats" style="margin-bottom:32px;">
        <div class="dash-stat">
          <div class="dash-stat__label">My Rooms</div>
          <div class="dash-stat__value"><?php echo $total; ?></div>
          <div class="dash-stat__sub">Assigned to you</div>
        </div>
        <div class="dash-stat">
          <div class="dash-stat__label">Occupied</div>
          <div class="dash-stat__value" style="color:var(--error);"><?php echo $occupied; ?></div>
          <div class="dash-stat__sub">Active guests</div>
        </div>
        <div class="dash-stat">
          <div class="dash-stat__label">Available</div>
          <div class="dash-stat__value" style="color:var(--forest);"><?php echo $available; ?></div>
          <div class="dash-stat__sub">Ready to book</div>
        </div>
        <div class="dash-stat">
          <div class="dash-stat__label">Maintenance</div>
          <div class="dash-stat__value" style="color:var(--gold);"><?php echo $maintenance; ?></div>
          <div class="dash-stat__sub">Under service</div>
        </div>
        <div class="dash-stat">
          <div class="dash-stat__label">Active Bookings</div>
          <div class="dash-stat__value" style="color:var(--forest);"><?php echo $activeBookings; ?></div>
          <div class="dash-stat__sub">Currently active</div>
        </div>
      </div>

      <!-- Section summary cards -->
      <div class="summary-grid">
        <div class="summary-card">
          <div class="summary-card__title">My Rooms</div>
          <div class="summary-card__stat"><?php echo $total; ?></div>
          <div class="summary-card__desc">
            <?php echo $available; ?> available &middot;
            <?php echo $occupied; ?> occupied &middot;
            <?php echo $maintenance; ?> maintenance
          </div>
          <a href="staff_rooms.php" class="btn btn--forest btn--sm" style="margin-top:6px;align-self:flex-start;">View My Rooms</a>
        </div>
        <div class="summary-card">
          <div class="summary-card__title">Bookings</div>
          <div class="summary-card__stat"><?php echo count($bookings); ?></div>
          <div class="summary-card__desc"><?php echo $activeBookings; ?> active booking<?php echo $activeBookings !== 1 ? 's' : ''; ?></div>
          <a href="staff_bookings.php" class="btn btn--forest btn--sm" style="margin-top:6px;align-self:flex-start;">View Bookings</a>
        </div>
        <div class="summary-card">
          <div class="summary-card__title">Alerts</div>
          <div class="summary-card__stat" style="color:<?php echo $alerts > 0 ? 'var(--error)' : 'var(--forest)'; ?>">
            <?php echo $alerts; ?>
          </div>
          <div class="summary-card__desc">
            <?php echo $alerts > 0 ? 'Occupied rooms — check sensor data' : 'No active alerts'; ?>
          </div>
          <a href="staff_alerts.php" class="btn btn--<?php echo $alerts > 0 ? 'danger' : 'forest'; ?> btn--sm" style="margin-top:6px;align-self:flex-start;">View Alerts</a>
        </div>
      </div>

    <?php endif; ?>

<?php include '../../includes/staff_layout_end.php'; ?>
