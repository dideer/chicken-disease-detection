<?php
/**
 * Wind Land Hotel — Staff Login
 * Backend: authenticates admin/staff and starts session.
 * Handles both super_admin and staff roles.
 */

require_once '../../config/config.php';
require_once '../../config/Database.php';
require_once '../../classes/Admin.php';

// Already logged in → go straight to dashboard
if (isset($_SESSION['admin_id'])) {
    header('Location: admin_dashboard.php');
    exit;
}

$error = '';

if (isset($_SESSION['timeout_msg'])) {
    $error = $_SESSION['timeout_msg'];
    unset($_SESSION['timeout_msg']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['staff_login'])) {
    $email    = trim($_POST['email']    ?? '');
    $password = trim($_POST['password'] ?? '');

    $admin  = new Admin();
    $result = $admin->login($email, $password);

    if ($result === 'inactive') {
        $error = 'Your account has been deactivated. Please contact the Super Admin.';
    } elseif ($result) {
        $_SESSION['admin_id']            = $result['id'];
        $_SESSION['admin_name']          = $result['full_name'];
        $_SESSION['admin_role']          = $result['role'];
        $_SESSION['admin_last_activity'] = time();
        // Route by role
        $dest = ($result['role'] === 'staff') ? 'staff_dashboard.php' : 'admin_dashboard.php';
        header('Location: ' . $dest);
        exit;
    } else {
        $error = 'Invalid email or password.';
    }
}

// ── HTML below is unchanged ───────────────────────────
$page_title = 'Staff Portal — Wind Land Hotel';
$base_path  = '../../';
include '../../includes/header.php';
?>

<div class="auth-wrap" style="background:var(--ink);">
  <div class="auth-card fade-in" style="border-color:rgba(184,150,62,0.2);">

    <div class="auth-card__badge" style="background:rgba(184,150,62,0.1);border-color:rgba(184,150,62,0.3);color:var(--gold);">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
      Staff Portal — Restricted Access
    </div>

    <h2>Staff Login</h2>
    <p class="auth-sub">Hotel management and operations access only.</p>

    <?php if (!empty($error)): ?>
      <div class="alert alert--error" role="alert"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form class="login-form" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST" novalidate>

      <div style="display:flex;flex-direction:column;gap:18px;">

        <div class="form-group">
          <label class="form-label" for="email">Staff Email</label>
          <input
            class="form-input"
            type="email"
            id="email"
            name="email"
            placeholder="staff@windlandhotel.rw"
            value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
            autocomplete="email"
            required
          />
          <span class="form-error" role="alert"></span>
        </div>

        <div class="form-group">
          <label class="form-label" for="password">Password</label>
          <div class="input-wrap">
            <input
              class="form-input"
              type="password"
              id="password"
              name="password"
              placeholder="Your staff password"
              autocomplete="current-password"
              required
            />
            <button type="button" class="toggle-pw" aria-label="Show password">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
            </button>
          </div>
          <span class="form-error" role="alert"></span>
        </div>

        <button type="submit" name="staff_login" class="btn btn--primary btn--full btn--lg" style="margin-top:4px;">
          Login to Staff Portal
        </button>

      </div>
    </form>

    <div class="auth-divider"><span>or</span></div>
    <p class="auth-footer">Not staff? <a href="../guest/login.php">Guest login &rarr;</a></p>

  </div>
</div>

<?php include '../../includes/footer.php'; ?>
