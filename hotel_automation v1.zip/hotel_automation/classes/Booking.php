<?php
/**
 * Wind Land Hotel — Booking Class
 * Handles all booking operations using MySQLi prepared statements.
 */

require_once __DIR__ . '/../config/Database.php';

class Booking
{
    private mysqli $db;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Return all bookings for a specific room, with guest details.
     */
    public function getByRoom(int $room_id): array
    {
        $stmt = $this->db->prepare(
            "SELECT b.id, b.room_id, b.check_in, b.check_out, b.status, b.created_at,
                    g.full_name, g.email, g.phone
             FROM bookings b
             JOIN guests g ON b.guest_id = g.id
             WHERE b.room_id = ?
             ORDER BY b.created_at DESC"
        );
        if (!$stmt) return [];
        $stmt->bind_param('i', $room_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    /**
     * Return all bookings for a set of room IDs, with guest details.
     * Uses a dynamic IN clause built with prepared statement placeholders.
     */
    public function getByRooms(array $room_ids): array
    {
        if (empty($room_ids)) return [];

        $placeholders = implode(',', array_fill(0, count($room_ids), '?'));
        $types        = str_repeat('i', count($room_ids));

        $stmt = $this->db->prepare(
            "SELECT b.id, b.room_id, b.check_in, b.check_out, b.status, b.created_at,
                    g.full_name, g.email, g.phone
             FROM bookings b
             JOIN guests g ON b.guest_id = g.id
             WHERE b.room_id IN ($placeholders)
             ORDER BY b.created_at DESC"
        );
        if (!$stmt) return [];

        $stmt->bind_param($types, ...$room_ids);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    /**
     * Return the single active booking for a room, or false if none.
     */
    public function getActiveByRoom(int $room_id): array|false
    {
        $stmt = $this->db->prepare(
            "SELECT b.id, b.room_id, b.check_in, b.check_out, b.status, b.created_at,
                    g.full_name, g.email, g.phone
             FROM bookings b
             JOIN guests g ON b.guest_id = g.id
             WHERE b.room_id = ? AND b.status = 'active'
             LIMIT 1"
        );
        if (!$stmt) return false;
        $stmt->bind_param('i', $room_id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $row ?? false;
    }

    /**
     * Cancel an active booking and free the room.
     */
    public function cancel(int $booking_id): bool
    {
        // Cancel the booking
        $stmt = $this->db->prepare(
            "UPDATE bookings SET status = 'cancelled'
             WHERE id = ? AND status = 'active'"
        );
        if (!$stmt) return false;
        $stmt->bind_param('i', $booking_id);
        $ok = $stmt->execute();
        $stmt->close();

        if (!$ok || $this->db->affected_rows === 0) return false;

        // Free the room
        $roomStmt = $this->db->prepare(
            "UPDATE rooms SET status = 'available'
             WHERE id = (SELECT room_id FROM bookings WHERE id = ?)"
        );
        if (!$roomStmt) return false;
        $roomStmt->bind_param('i', $booking_id);
        $roomStmt->execute();
        $roomStmt->close();

        return true;
    }

    /**
     * Check out a guest: mark booking as checked_out, free the room,
     * and expire the associated PIN.
     */
    public function checkout(int $booking_id): bool
    {
        // Mark booking as checked_out
        $stmt = $this->db->prepare(
            "UPDATE bookings SET status = 'checked_out'
             WHERE id = ? AND status = 'active'"
        );
        if (!$stmt) return false;
        $stmt->bind_param('i', $booking_id);
        $ok = $stmt->execute();
        $stmt->close();

        if (!$ok || $this->db->affected_rows === 0) return false;

        // Free the room
        $roomStmt = $this->db->prepare(
            "UPDATE rooms SET status = 'available'
             WHERE id = (SELECT room_id FROM bookings WHERE id = ?)"
        );
        if (!$roomStmt) return false;
        $roomStmt->bind_param('i', $booking_id);
        $roomStmt->execute();
        $roomStmt->close();

        // Expire the PIN for this booking (if pins table exists)
        $pinStmt = $this->db->prepare(
            "UPDATE pins SET is_expired = 1 WHERE booking_id = ?"
        );
        if ($pinStmt) {
            $pinStmt->bind_param('i', $booking_id);
            $pinStmt->execute();
            $pinStmt->close();
        }

        return true;
    }

    /**
     * Automatically check out all bookings whose check_out date has passed.
     * Marks them as 'checked_out', frees the rooms, and expires the PINs.
     * Call this on every page load (staff bootstrap or guest auth).
     *
     * @return int  Number of bookings automatically checked out
     */
    public function autoCheckoutExpired(): int
    {
        // Find all active bookings where check_out date is in the past
        $stmt = $this->db->prepare(
            "SELECT id, room_id FROM bookings
             WHERE status = 'active' AND check_out < CURDATE()"
        );
        if (!$stmt) return 0;
        $stmt->execute();
        $expired = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        if (empty($expired)) return 0;

        $count = 0;
        foreach ($expired as $b) {
            $bid = (int)$b['id'];

            // Mark checked_out
            $u = $this->db->prepare(
                "UPDATE bookings SET status = 'checked_out' WHERE id = ? AND status = 'active'"
            );
            if (!$u) continue;
            $u->bind_param('i', $bid);
            $u->execute();
            $affected = $this->db->affected_rows;
            $u->close();

            if ($affected === 0) continue;

            // Free the room
            $r = $this->db->prepare(
                "UPDATE rooms SET status = 'available' WHERE id = ?"
            );
            if ($r) {
                $rid = (int)$b['room_id'];
                $r->bind_param('i', $rid);
                $r->execute();
                $r->close();
            }

            // Expire the PIN
            $p = $this->db->prepare(
                "UPDATE pins SET is_expired = 1 WHERE booking_id = ?"
            );
            if ($p) {
                $p->bind_param('i', $bid);
                $p->execute();
                $p->close();
            }

            $count++;
        }

        return $count;
    }

    /**
     * Return a single booking with guest details by booking id.
     */
    public function getById(int $id): array|false
    {
        $stmt = $this->db->prepare(
            "SELECT b.id, b.room_id, b.check_in, b.check_out, b.status, b.created_at,
                    g.full_name, g.email, g.phone
             FROM bookings b
             JOIN guests g ON b.guest_id = g.id
             WHERE b.id = ?
             LIMIT 1"
        );
        if (!$stmt) return false;
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $row ?? false;
    }
}
