<?php
/**
 * Wind Land Hotel — RoomAssignment Class
 * Manages which staff member is responsible for which room range.
 */

require_once __DIR__ . '/../config/Database.php';

class RoomAssignment
{
    private mysqli $db;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Assign a room range to a staff member.
     * First checks for any overlap with existing assignments.
     * Returns false if overlap found, true on successful insert.
     */
    public function assign(int $admin_id, string $room_from, string $room_to): bool
    {
        // Check for range overlap with ANY existing assignment
        $check = $this->db->prepare(
            "SELECT id FROM room_assignments
             WHERE (room_from BETWEEN ? AND ?)
                OR (room_to   BETWEEN ? AND ?)
                OR (? BETWEEN room_from AND room_to)
                OR (? BETWEEN room_from AND room_to)
             LIMIT 1"
        );
        if (!$check) return false;
        $check->bind_param('ssssss', $room_from, $room_to,
                                     $room_from, $room_to,
                                     $room_from, $room_to);
        $check->execute();
        $check->store_result();
        $overlap = $check->num_rows > 0;
        $check->close();

        if ($overlap) return false;

        $stmt = $this->db->prepare(
            "INSERT INTO room_assignments (admin_id, room_from, room_to) VALUES (?, ?, ?)"
        );
        if (!$stmt) return false;
        $stmt->bind_param('iss', $admin_id, $room_from, $room_to);
        $ok = $stmt->execute();
        $stmt->close();
        return $ok;
    }

    /**
     * Return all assignments joined with admin full_name and email.
     */
    public function getAll(): array
    {
        $stmt = $this->db->prepare(
            "SELECT ra.id, ra.admin_id, ra.room_from, ra.room_to,
                    a.full_name, a.email
             FROM room_assignments ra
             JOIN admins a ON ra.admin_id = a.id
             ORDER BY a.full_name ASC"
        );
        if (!$stmt) return [];
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    /**
     * Return the assignment for a specific staff member, or false if none.
     */
    public function getByStaff(int $admin_id): array|false
    {
        $stmt = $this->db->prepare(
            "SELECT id, admin_id, room_from, room_to
             FROM room_assignments
             WHERE admin_id = ?
             LIMIT 1"
        );
        if (!$stmt) return false;
        $stmt->bind_param('i', $admin_id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $row ?? false;
    }

    /**
     * Remove an assignment by its id.
     */
    public function delete(int $id): bool
    {
        $stmt = $this->db->prepare("DELETE FROM room_assignments WHERE id = ?");
        if (!$stmt) return false;
        $stmt->bind_param('i', $id);
        $ok = $stmt->execute();
        $stmt->close();
        return $ok;
    }
}
