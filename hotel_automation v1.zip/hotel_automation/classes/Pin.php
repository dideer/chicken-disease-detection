<?php
/**
 * Wind Land Hotel — Pin Class
 * Handles PIN generation, validation, and expiry.
 */

require_once __DIR__ . '/../config/Database.php';

class Pin
{
    private mysqli $db;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Generate a random 6-digit PIN and store it.
     * Returns the pin_code string on success, or false on failure.
     */
    public function generate(int $booking_id, int $room_id, string $expires_at): string|false
    {
        $pin_code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);

        $stmt = $this->db->prepare(
            "INSERT INTO pins (booking_id, room_id, pin_code, is_expired, failed_attempts, expires_at)
             VALUES (?, ?, ?, 0, 0, ?)"
        );
        if (!$stmt) return false;

        $stmt->bind_param('iiss', $booking_id, $room_id, $pin_code, $expires_at);
        $ok = $stmt->execute();
        $stmt->close();

        return $ok ? $pin_code : false;
    }

    /**
     * Return the latest non-expired PIN for a booking, or false.
     */
    public function getByBooking(int $booking_id): array|false
    {
        $stmt = $this->db->prepare(
            "SELECT id, booking_id, room_id, pin_code, is_expired, failed_attempts, expires_at, created_at
             FROM pins
             WHERE booking_id = ? AND is_expired = 0
             ORDER BY created_at DESC
             LIMIT 1"
        );
        if (!$stmt) return false;

        $stmt->bind_param('i', $booking_id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        return $row ?? false;
    }

    /**
     * Validate a PIN for a room.
     * Returns the pin array if valid.
     * Increments failed_attempts on mismatch; expires PIN after 3 failures.
     */
    public function validate(int $room_id, string $pin_code): array|false
    {
        $stmt = $this->db->prepare(
            "SELECT id, booking_id, room_id, pin_code, failed_attempts, expires_at
             FROM pins
             WHERE room_id = ? AND pin_code = ? AND is_expired = 0 AND expires_at > NOW()
             LIMIT 1"
        );
        if (!$stmt) return false;

        $stmt->bind_param('is', $room_id, $pin_code);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($row) {
            return $row;
        }

        // Increment failed attempts
        $upd = $this->db->prepare(
            "UPDATE pins SET failed_attempts = failed_attempts + 1
             WHERE room_id = ? AND pin_code = ? AND is_expired = 0"
        );
        if ($upd) {
            $upd->bind_param('is', $room_id, $pin_code);
            $upd->execute();
            $upd->close();
        }

        // Expire after 3 failed attempts
        $exp = $this->db->prepare(
            "UPDATE pins SET is_expired = 1
             WHERE room_id = ? AND pin_code = ? AND failed_attempts >= 3"
        );
        if ($exp) {
            $exp->bind_param('is', $room_id, $pin_code);
            $exp->execute();
            $exp->close();
        }

        return false;
    }

    /**
     * Expire all active PINs for a booking.
     */
    public function expire(int $booking_id): bool
    {
        $stmt = $this->db->prepare(
            "UPDATE pins SET is_expired = 1 WHERE booking_id = ?"
        );
        if (!$stmt) return false;

        $stmt->bind_param('i', $booking_id);
        $ok = $stmt->execute();
        $stmt->close();

        return $ok;
    }
}
