<?php
/**
 * Wind Land Hotel — Room Class
 * Handles all room data operations using MySQLi prepared statements.
 */

require_once __DIR__ . '/../config/Database.php';

class Room
{
    private mysqli $db;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Return all rooms ordered by room_number ASC.
     */
    public function getAll(): array
    {
        $stmt = $this->db->prepare(
            "SELECT id, room_number, floor, type, price, status, created_at
             FROM rooms
             ORDER BY room_number ASC"
        );
        if (!$stmt) return [];
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    /**
     * Return a single room by id, or false if not found.
     */
    public function getById(int $id): array|false
    {
        $stmt = $this->db->prepare(
            "SELECT id, room_number, floor, type, price, status FROM rooms WHERE id = ? LIMIT 1"
        );
        if (!$stmt) return false;
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $row ?? false;
    }

    /**
     * Return all rooms where status = 'available'.
     */
    public function getAvailable(): array
    {
        $stmt = $this->db->prepare(
            "SELECT id, room_number, floor, type, price, status
             FROM rooms
             WHERE status = 'available'
             ORDER BY room_number ASC"
        );
        if (!$stmt) return [];
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    /**
     * Return rooms assigned to a specific staff member via room_assignments.
     * Matches rooms whose room_number falls BETWEEN room_from AND room_to.
     */
    public function getByStaff(int $admin_id): array
    {
        $stmt = $this->db->prepare(
            "SELECT r.id, r.room_number, r.floor, r.type, r.price, r.status
             FROM rooms r
             JOIN room_assignments ra ON r.room_number BETWEEN ra.room_from AND ra.room_to
             WHERE ra.admin_id = ?
             ORDER BY r.room_number ASC"
        );
        if (!$stmt) return [];
        $stmt->bind_param('i', $admin_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    /**
     * Update a room's status.
     * $status must be 'available', 'occupied', or 'maintenance'.
     */
    public function updateStatus(int $id, string $status): bool
    {
        $allowed = ['available', 'occupied', 'maintenance'];
        if (!in_array($status, $allowed, true)) return false;

        $stmt = $this->db->prepare("UPDATE rooms SET status = ? WHERE id = ?");
        if (!$stmt) return false;
        $stmt->bind_param('si', $status, $id);
        $ok = $stmt->execute();
        $stmt->close();
        return $ok;
    }

    /**
     * Insert a new room. Status defaults to 'available'.
     */
    public function create(string $room_number, int $floor, string $type, float $price): bool
    {
        $stmt = $this->db->prepare(
            "INSERT INTO rooms (room_number, floor, type, price, status)
             VALUES (?, ?, ?, ?, 'available')"
        );
        if (!$stmt) return false;
        $stmt->bind_param('sisd', $room_number, $floor, $type, $price);
        $ok = $stmt->execute();
        $stmt->close();
        return $ok;
    }

    /**
     * Delete a room by id.
     */
    public function delete(int $id): bool
    {
        $stmt = $this->db->prepare("DELETE FROM rooms WHERE id = ?");
        if (!$stmt) return false;
        $stmt->bind_param('i', $id);
        $ok = $stmt->execute();
        $stmt->close();
        return $ok;
    }
}
