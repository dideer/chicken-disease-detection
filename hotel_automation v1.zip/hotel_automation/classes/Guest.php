<?php
/**
 * Wind Land Hotel — Guest Class
 * Handles guest authentication and account operations.
 */

require_once __DIR__ . '/../config/Database.php';

class Guest
{
    private mysqli $db;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Attempt to log in a guest by email and password.
     *
     * Returns an associative array with guest data on success,
     * or false on failure.
     *
     * @param  string       $email
     * @param  string       $password  Plain-text password to verify
     * @return array|false
     */
    public function login(string $email, string $password): array|false
    {
        $stmt = $this->db->prepare(
            "SELECT id, full_name, email, password FROM guests WHERE email = ? LIMIT 1"
        );

        if (!$stmt) {
            return false;
        }

        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $guest  = $result->fetch_assoc();
        $stmt->close();

        if (!$guest) {
            return false;
        }

        if (!password_verify($password, $guest['password'])) {
            return false;
        }

        // Don't expose the hashed password outside this class
        unset($guest['password']);

        return $guest;
    }

    /**
     * Register a new guest account.
     * Returns ['success' => true, 'id' => int] or ['error' => string].
     */
    public function register(string $full_name, string $email, string $phone, string $password): array
    {
        // Check email uniqueness
        $check = $this->db->prepare("SELECT id FROM guests WHERE email = ? LIMIT 1");
        if (!$check) return ['error' => 'Database error. Please try again.'];
        $check->bind_param('s', $email);
        $check->execute();
        $check->store_result();
        if ($check->num_rows > 0) {
            $check->close();
            return ['error' => 'Email already registered. Please log in.'];
        }
        $check->close();

        $hash = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $this->db->prepare(
            "INSERT INTO guests (full_name, email, phone, password) VALUES (?, ?, ?, ?)"
        );
        if (!$stmt) return ['error' => 'Database error. Please try again.'];

        $stmt->bind_param('ssss', $full_name, $email, $phone, $hash);
        $ok = $stmt->execute();
        $id = $this->db->insert_id;
        $stmt->close();

        if (!$ok) return ['error' => 'Registration failed. Please try again.'];

        return ['success' => true, 'id' => $id];
    }

    /**
     * Return a guest by id (without password), or false if not found.
     */
    public function getById(int $id): array|false
    {
        $stmt = $this->db->prepare(
            "SELECT id, full_name, email, phone, created_at FROM guests WHERE id = ? LIMIT 1"
        );
        if (!$stmt) return false;
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $row ?? false;
    }
}
