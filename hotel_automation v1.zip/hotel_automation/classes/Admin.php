<?php
/**
 * Wind Land Hotel — Admin Class
 * Handles staff/admin authentication (super_admin and staff roles).
 */

require_once __DIR__ . '/../config/Database.php';

class Admin
{
    private mysqli $db;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Attempt to log in an admin/staff member by email and password.
     *
     * Returns an associative array with admin data (id, full_name, role)
     * on success, or false on failure.
     * Returns 'inactive' string if account exists but is deactivated.
     *
     * @param  string            $email
     * @param  string            $password  Plain-text password to verify
     * @return array|false|string
     */
    public function login(string $email, string $password): array|false|string
    {
        $stmt = $this->db->prepare(
            "SELECT id, full_name, email, password, role, is_active
             FROM admins WHERE email = ? LIMIT 1"
        );

        if (!$stmt) return false;

        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $admin  = $result->fetch_assoc();
        $stmt->close();

        if (!$admin) return false;
        if (!password_verify($password, $admin['password'])) return false;

        // Account exists and password is correct — check active status
        if ((int)$admin['is_active'] === 0) {
            return 'inactive';   // Caller must handle this explicitly
        }

        unset($admin['password']);
        return $admin;
    }

    /**
     * Return all staff accounts (role = 'staff') ordered by name.
     */
    public function getAllStaff(): array
    {
        $stmt = $this->db->prepare(
            "SELECT id, full_name, email, role, is_active, created_at
             FROM admins
             WHERE role = 'staff'
             ORDER BY full_name ASC"
        );
        if (!$stmt) return [];
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    /**
     * Create a new staff account.
     */
    public function createStaff(string $full_name, string $email, string $hashed_password): bool
    {
        $stmt = $this->db->prepare(
            "INSERT INTO admins (full_name, email, password, role, is_active)
             VALUES (?, ?, ?, 'staff', 1)"
        );
        if (!$stmt) return false;
        $stmt->bind_param('sss', $full_name, $email, $hashed_password);
        $ok = $stmt->execute();
        $stmt->close();
        return $ok;
    }

    /**
     * Delete a staff account by id.
     */
    public function deleteStaff(int $id): bool
    {
        $stmt = $this->db->prepare("DELETE FROM admins WHERE id = ? AND role = 'staff'");
        if (!$stmt) return false;
        $stmt->bind_param('i', $id);
        $ok = $stmt->execute();
        $stmt->close();
        return $ok;
    }

    /**
     * Toggle is_active for a staff member (1 → 0, 0 → 1).
     */
    public function toggleActive(int $id): bool
    {
        $stmt = $this->db->prepare(
            "UPDATE admins SET is_active = IF(is_active = 1, 0, 1) WHERE id = ? AND role = 'staff'"
        );
        if (!$stmt) return false;
        $stmt->bind_param('i', $id);
        $ok = $stmt->execute();
        $stmt->close();
        return $ok;
    }
}
