<?php
/**
 * Wind Land Hotel — Staff Bootstrap
 * Loaded at the top of every staff page.
 * Handles auth, data loading, stats calculation, PRG actions, and flash messages.
 *
 * After including this file the page has access to:
 *   $assignment, $assignedRooms, $roomIds, $bookings,
 *   $noAssignment, $total, $occupied, $available,
 *   $maintenance, $activeBookings, $alerts,
 *   $activeBookingByRoom, $greeting,
 *   $flashSuccess, $flashError
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../classes/Admin.php';
require_once __DIR__ . '/../classes/Room.php';
require_once __DIR__ . '/../classes/Booking.php';
require_once __DIR__ . '/../classes/RoomAssignment.php';
require_once __DIR__ . '/../includes/admin_auth.php';

// Staff only
if ($admin_role !== 'staff') {
    header('Location: ' . BASE_URL . '/pages/admin/admin_dashboard.php');
    exit;
}

$roomObj    = new Room();
$assignObj  = new RoomAssignment();
$bookingObj = new Booking();

// ── Auto-checkout expired bookings on every staff page load ──
$bookingObj->autoCheckoutExpired();

$assignment    = $assignObj->getByStaff((int)$_SESSION['admin_id']);
$assignedRooms = $roomObj->getByStaff((int)$_SESSION['admin_id']);
$noAssignment  = empty($assignment) || empty($assignedRooms);

if ($noAssignment) {
    $assignedRooms = [];
    $roomIds       = [];
    $bookings      = [];
} else {
    $roomIds  = array_column($assignedRooms, 'id');
    $bookings = $bookingObj->getByRooms($roomIds);
}

// Stats
$total          = count($assignedRooms);
$occupied       = count(array_filter($assignedRooms, fn($r) => $r['status'] === 'occupied'));
$available      = count(array_filter($assignedRooms, fn($r) => $r['status'] === 'available'));
$maintenance    = count(array_filter($assignedRooms, fn($r) => $r['status'] === 'maintenance'));
$activeBookings = count(array_filter($bookings,      fn($b) => $b['status'] === 'active'));
$alerts         = $occupied;

// Quick lookup: room_id → active booking
$activeBookingByRoom = [];
foreach ($bookings as $b) {
    if ($b['status'] === 'active') {
        $activeBookingByRoom[(int)$b['room_id']] = $b;
    }
}

// Greeting
$hour     = (int)date('G');
$greeting = $hour < 12 ? 'Good morning' : ($hour < 17 ? 'Good afternoon' : 'Good evening');

// Flash messages
$successMessages = [
    'booking_cancelled' => 'Booking cancelled successfully.',
    'guest_checked_out' => 'Guest checked out successfully.',
];
$errorMessages = [
    'unauthorized'  => 'You are not authorized to perform that action.',
    'action_failed' => 'Action failed. Please try again.',
];
$flashSuccess = isset($_GET['success']) ? ($successMessages[$_GET['success']] ?? '') : '';
$flashError   = isset($_GET['error'])   ? ($errorMessages[$_GET['error']]     ?? '') : '';

// PRG — handle POST actions (checkout / cancel)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action     = $_POST['action']     ?? '';
    $booking_id = (int)($_POST['booking_id'] ?? 0);

    $verifiedBooking = $bookingObj->getById($booking_id);
    $authorized      = $verifiedBooking
                       && !empty($roomIds)
                       && in_array((int)$verifiedBooking['room_id'], $roomIds, true);

    if (!$authorized) {
        header('Location: ' . htmlspecialchars($_SERVER['PHP_SELF']) . '?error=unauthorized');
        exit;
    }

    if ($action === 'cancel_booking') {
        $ok    = $bookingObj->cancel($booking_id);
        $param = $ok ? '?success=booking_cancelled' : '?error=action_failed';
        header('Location: ' . htmlspecialchars($_SERVER['PHP_SELF']) . $param);
        exit;
    }

    // checkout_guest is NOT allowed for staff — system handles it automatically

    header('Location: ' . htmlspecialchars($_SERVER['PHP_SELF']));
    exit;
}

define('STAFF_LAYOUT', true);
