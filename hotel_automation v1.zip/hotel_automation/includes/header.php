<?php
/**
 * Wind Land Hotel — Global Header
 * Include this at the top of every page.
 * $page_title  — set before including to override <title>
 * $base_path   — set to '' for root, '../../' for nested pages
 */
if (!isset($page_title)) $page_title = 'Wind Land Hotel — Smart Comfort in Rwanda';
if (!isset($base_path))  $base_path  = '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="Wind Land Hotel — A smart luxury hotel in Rwanda with automated room control, PIN-based access, and 24/7 intelligent systems." />
  <meta name="theme-color" content="#0E1612" />
  <title><?php echo htmlspecialchars($page_title); ?></title>

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400;1,600&family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet" />

  <!-- Global Stylesheet -->
  <link rel="stylesheet" href="<?php echo $base_path; ?>assets/css/style.css" />
</head>
<body>

<!-- ═══ NAVIGATION ═══════════════════════════════════════ -->
<nav class="nav" role="navigation" aria-label="Main navigation">
  <div class="nav__inner">

    <!-- Logo -->
    <a href="<?php echo $base_path; ?>index.php" class="nav__logo" aria-label="Wind Land Hotel home">
      <span class="nav__logo-name">WindLand</span>
      <span class="nav__logo-tag">Smart Hotel · Rwanda</span>
    </a>

    <!-- Desktop links -->
    <ul class="nav__links" role="list">
      <li><a href="<?php echo $base_path; ?>pages/guest/rooms.php" class="nav__link">Rooms</a></li>
      <li><a href="<?php echo $base_path; ?>index.php#how-it-works" class="nav__link">How it Works</a></li>
      <li><a href="<?php echo $base_path; ?>pages/guest/booking.php" class="nav__link">Book Now</a></li>
    </ul>

    <!-- Desktop action buttons -->
    <div class="nav__actions">
      <?php if (isset($_SESSION['guest_id'])): ?>
        <span class="nav__btn-ghost" style="cursor:default;pointer-events:none;">
          <?php echo htmlspecialchars($_SESSION['guest_name'] ?? 'Guest'); ?>
        </span>
        <a href="<?php echo $base_path; ?>pages/guest/guest_dashboard.php" class="nav__btn-ghost">My Dashboard</a>
        <a href="<?php echo $base_path; ?>pages/guest/logout.php" class="nav__btn-cta">Logout</a>
      <?php elseif (isset($_SESSION['admin_id'])): ?>
        <span class="nav__btn-ghost" style="cursor:default;pointer-events:none;">
          <?php echo htmlspecialchars($_SESSION['admin_name'] ?? 'Staff'); ?>
        </span>
        <a href="<?php echo $base_path; ?>pages/admin/logout.php" class="nav__btn-cta">Logout</a>
      <?php else: ?>
        <a href="<?php echo $base_path; ?>pages/guest/login.php" class="nav__btn-ghost">Guest Login</a>
        <a href="<?php echo $base_path; ?>pages/admin/login.php" class="nav__btn-cta">Staff Login</a>
      <?php endif; ?>
    </div>

    <!-- Hamburger -->
    <button class="nav__hamburger" aria-label="Toggle navigation menu" aria-expanded="false" aria-controls="mobile-nav">
      <span></span>
      <span></span>
      <span></span>
    </button>

  </div><!-- /.nav__inner -->

  <!-- Mobile drawer -->
  <nav class="nav__mobile" id="mobile-nav" aria-label="Mobile navigation">
    <a href="<?php echo $base_path; ?>pages/guest/rooms.php" class="nav__link">Rooms</a>
    <a href="<?php echo $base_path; ?>index.php#how-it-works" class="nav__link">How it Works</a>
    <a href="<?php echo $base_path; ?>pages/guest/booking.php" class="nav__link">Book Now</a>
    <div class="nav__actions">
      <?php if (isset($_SESSION['guest_id'])): ?>
        <a href="<?php echo $base_path; ?>pages/guest/guest_dashboard.php" class="nav__btn-ghost">My Dashboard</a>
        <a href="<?php echo $base_path; ?>pages/guest/logout.php" class="nav__btn-cta">Logout</a>
      <?php elseif (isset($_SESSION['admin_id'])): ?>
        <a href="<?php echo $base_path; ?>pages/admin/logout.php" class="nav__btn-cta">Logout</a>
      <?php else: ?>
        <a href="<?php echo $base_path; ?>pages/guest/login.php" class="nav__btn-ghost">Guest Login</a>
        <a href="<?php echo $base_path; ?>pages/admin/login.php" class="nav__btn-cta">Staff Login</a>
      <?php endif; ?>
    </div>
  </nav>

</nav><!-- /.nav -->

<!-- Page content follows -->
<main role="main">
