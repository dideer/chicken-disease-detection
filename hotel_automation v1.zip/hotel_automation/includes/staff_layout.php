<?php
/**
 * Wind Land Hotel — Staff Layout Include
 * Shared HTML head, topbar, sidebar and closing scripts
 * for all staff pages. Not for direct browser access.
 *
 * Expects these variables already defined by the including page:
 *   $pageTitle   (string)  — <title> value
 *   $assignment  (array|false)
 *   $alerts      (int)     — count of occupied rooms
 */
if (!defined('STAFF_LAYOUT')) die('Direct access not permitted.');

$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?php echo htmlspecialchars($pageTitle ?? 'Staff Panel'); ?> — Wind Land Hotel</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400;1,600&family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="../../assets/css/style.css" />
  <style>
    /* ── Layout ─────────────────────────────────────────── */
    .admin-topbar {
      position: fixed; top: 0; left: 0; right: 0;
      height: 60px;
      background: var(--ink);
      border-bottom: 1px solid rgba(184,150,62,0.2);
      display: flex; align-items: center; justify-content: space-between;
      padding: 0 28px; z-index: 1000;
    }
    .admin-topbar__brand {
      font-family: var(--font-head); font-size: 1.2rem;
      font-weight: 600; color: var(--white); letter-spacing: 0.04em;
    }
    .admin-topbar__brand span {
      font-family: var(--font-mono); font-size: 0.62rem; color: var(--gold);
      letter-spacing: 0.14em; text-transform: uppercase; display: block; margin-top: 2px;
    }
    .admin-topbar__right { display: flex; align-items: center; gap: 16px; }
    .admin-topbar__user  { font-size: 0.82rem; color: rgba(253,252,248,0.6); }
    .admin-topbar__user strong { color: var(--white); font-weight: 600; }
    .admin-layout { padding-top: 60px; min-height: 100vh; display: flex; }
    .admin-sidebar {
      width: 240px; background: var(--ink);
      border-right: 1px solid rgba(255,255,255,0.07);
      position: fixed; top: 60px; left: 0; bottom: 0;
      overflow-y: auto; padding: 20px 0 32px; z-index: 900;
    }
    .admin-content {
      margin-left: 240px; flex: 1;
      background: var(--paper); padding: 32px;
      min-height: calc(100vh - 60px);
    }
    /* Alert room card */
    .alert-room-card {
      display: flex; align-items: center; justify-content: space-between;
      flex-wrap: wrap; gap: 12px; padding: 18px 20px;
      background: var(--white); border: 1px solid var(--border);
      border-left: 4px solid var(--error);
      border-radius: var(--radius); margin-bottom: 12px;
    }
    .alert-room-card__left  { display: flex; align-items: center; gap: 14px; }
    .alert-room-card__right { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
    /* Summary cards */
    .summary-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
      gap: 20px; margin-top: 24px;
    }
    .summary-card {
      background: var(--white); border: 1px solid var(--border);
      border-radius: var(--radius); padding: 24px;
      display: flex; flex-direction: column; gap: 10px;
      transition: all var(--transition);
    }
    .summary-card:hover { border-color: var(--gold-pale); box-shadow: var(--shadow); transform: translateY(-3px); }
    .summary-card__title {
      font-family: var(--font-mono); font-size: 0.68rem;
      letter-spacing: 0.14em; text-transform: uppercase; color: var(--gold);
    }
    .summary-card__stat {
      font-family: var(--font-head); font-size: 2rem;
      font-weight: 600; color: var(--forest); line-height: 1;
    }
    .summary-card__desc { font-size: 0.82rem; color: var(--text-muted); }
    /* ── Responsive ─────────────────────────────────────── */
    @media (max-width: 1024px) {
      .admin-sidebar { width: 200px; }
      .admin-content { margin-left: 200px; padding: 24px; }
      .summary-grid  { grid-template-columns: repeat(auto-fill, minmax(180px,1fr)); gap:16px; }
    }
    @media (max-width: 768px) {
      #sidebar-toggle    { display: flex !important; }
      .admin-topbar      { padding: 0 16px; height: 56px; }
      .admin-topbar__brand { font-size: 1rem; }
      .admin-topbar__brand span { font-size: 0.58rem; }
      .admin-topbar__user { display: none; }
      .admin-topbar__right { gap: 10px; }
      .admin-layout      { padding-top: 56px; }
      .admin-sidebar {
        transform: translateX(-100%);
        transition: transform 0.28s cubic-bezier(0.4,0,0.2,1);
        display: block !important; width: 240px;
      }
      .admin-sidebar.open { transform: translateX(0); }
      .admin-content { margin-left: 0; padding: 20px 16px; }
      .dash-stats    { grid-template-columns: repeat(2,1fr) !important; gap: 12px !important; }
      .summary-grid  { grid-template-columns: 1fr 1fr; gap: 12px; }
      .table-wrap    { font-size: 0.8rem; }
      thead th, tbody td { padding: 10px 12px; }
    }
    @media (max-width: 480px) {
      .admin-topbar  { padding: 0 12px; }
      .admin-content { padding: 16px 12px; }
      .dash-stats    { grid-template-columns: 1fr !important; gap: 10px !important; }
      .dash-stat     { padding: 16px !important; }
      .summary-grid  { grid-template-columns: 1fr; }
      .alert-room-card { flex-direction: column; align-items: flex-start; }
    }
  </style>
</head>
<body>

<!-- TOP NAVBAR -->
<header class="admin-topbar">
  <div style="display:flex;align-items:center;gap:14px;">
    <button id="sidebar-toggle" aria-label="Toggle navigation" aria-expanded="false" style="
      display:none;flex-direction:column;gap:5px;padding:6px;
      background:none;border:none;cursor:pointer;border-radius:6px;">
      <span style="display:block;width:20px;height:2px;background:var(--white);border-radius:2px;transition:all .25s;"></span>
      <span style="display:block;width:20px;height:2px;background:var(--white);border-radius:2px;transition:all .25s;"></span>
      <span style="display:block;width:20px;height:2px;background:var(--white);border-radius:2px;transition:all .25s;"></span>
    </button>
    <div class="admin-topbar__brand">
      WindLand Hotel <span>Staff Panel</span>
    </div>
  </div>
  <div class="admin-topbar__right">
    <div class="admin-topbar__user">
      Logged in as <strong><?php echo htmlspecialchars($_SESSION['admin_name']); ?></strong>
      &nbsp;<span class="badge badge--green" style="font-size:0.62rem;">Staff</span>
    </div>
    <a href="logout.php" class="btn btn--danger btn--sm">Logout</a>
  </div>
</header>

<!-- Mobile overlay -->
<div id="sidebar-overlay" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.55);z-index:850;backdrop-filter:blur(2px);"></div>

<div class="admin-layout">

  <!-- SIDEBAR -->
  <aside class="admin-sidebar" role="navigation" aria-label="Staff navigation">

    <div class="admin-sidebar__brand">
      <p>Staff Panel</p>
      <h4>WindLand Hotel</h4>
      <div style="margin-top:8px;">
        <span class="badge badge--green" style="font-size:0.65rem;">Staff</span>
      </div>
      <div style="margin-top:6px;font-size:0.78rem;color:rgba(253,252,248,0.45);">
        <?php echo htmlspecialchars($_SESSION['admin_name']); ?>
      </div>
      <div style="margin-top:10px;">
        <?php if (!empty($assignment)): ?>
          <span style="font-family:var(--font-mono);background:rgba(184,150,62,0.12);color:var(--gold);
            border:1px solid rgba(184,150,62,0.3);font-size:0.72rem;padding:3px 10px;
            border-radius:100px;letter-spacing:0.04em;">
            Rooms: <?php echo htmlspecialchars($assignment['room_from']); ?>
            &ndash; <?php echo htmlspecialchars($assignment['room_to']); ?>
          </span>
        <?php else: ?>
          <span style="font-size:0.75rem;color:rgba(253,252,248,0.3);">No rooms assigned</span>
        <?php endif; ?>
      </div>
    </div>

    <div class="admin-nav__section-label">Menu</div>

    <a href="staff_dashboard.php" class="admin-nav__link <?= $currentPage==='staff_dashboard.php' ? 'active' : '' ?>">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
      Dashboard Overview
    </a>
    <a href="staff_rooms.php" class="admin-nav__link <?= $currentPage==='staff_rooms.php' ? 'active' : '' ?>">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
      My Rooms
    </a>
    <a href="staff_bookings.php" class="admin-nav__link <?= $currentPage==='staff_bookings.php' ? 'active' : '' ?>">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
      Bookings
    </a>
    <a href="staff_alerts.php" class="admin-nav__link <?= $currentPage==='staff_alerts.php' ? 'active' : '' ?>">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
      Alerts
      <?php if (!empty($alerts) && $alerts > 0): ?>
        <span class="badge badge--red" style="margin-left:auto;font-size:0.62rem;"><?php echo (int)$alerts; ?></span>
      <?php endif; ?>
    </a>

    <div class="admin-nav__section-label" style="margin-top:16px;">Account</div>
    <a href="logout.php" class="admin-nav__link" style="color:rgba(231,76,60,0.75);"
       onmouseover="this.style.color='#E74C3C'" onmouseout="this.style.color='rgba(231,76,60,0.75)'">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
      Logout
    </a>

    <div class="admin-nav__section-label" style="margin-top:16px;">Clock</div>
    <div style="padding:6px 24px;font-family:var(--font-mono);font-size:0.72rem;color:rgba(253,252,248,0.3);">
      <span id="clock"></span>
    </div>
  </aside>

  <!-- MAIN CONTENT injected by each page -->
  <div class="admin-content">
