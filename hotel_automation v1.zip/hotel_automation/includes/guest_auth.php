<?php
/**
 * Wind Land Hotel — Guest Authentication Guard
 * Checks for a valid guest session and enforces a 30-minute idle timeout.
 * Redirects to the guest login page if the session is absent or expired.
 */

require_once __DIR__ . '/../config/config.php';

// ── Session timeout check ──────────────────────────────
if (isset($_SESSION['guest_id'])) {
    $idle = time() - ($_SESSION['guest_last_activity'] ?? time());

    if ($idle > SESSION_TIMEOUT) {
        // Session has expired — destroy it cleanly
        session_unset();
        session_destroy();

        // Restart a clean session to carry the flash message
        session_start();
        $_SESSION['timeout_msg'] = 'Your session expired after 30 minutes of inactivity. Please log in again.';

        header('Location: ' . BASE_URL . '/pages/guest/login.php');
        exit;
    }

    // Refresh the activity timestamp on every valid request
    $_SESSION['guest_last_activity'] = time();
}

// ── Authentication check ───────────────────────────────
if (!isset($_SESSION['guest_id'])) {
    header('Location: ' . BASE_URL . '/pages/guest/login.php');
    exit;
}
