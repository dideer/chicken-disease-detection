<?php if (!isset($base_path)) $base_path = ''; ?>

</main><!-- /main -->

<!-- ═══ FOOTER ══════════════════════════════════════════ -->
<footer class="footer" role="contentinfo">
  <div class="footer__inner">

    <!-- Brand -->
    <div class="footer__brand">
      <p class="footer__logo">WindLand Hotel</p>
      <p>Smart comfort, naturally yours.<br>Kigali, Rwanda</p>
    </div>

    <!-- Quick links -->
    <div class="footer__links">
      <h6>Explore</h6>
      <ul>
        <li><a href="<?php echo $base_path; ?>pages/guest/rooms.php">Rooms</a></li>
        <li><a href="<?php echo $base_path; ?>pages/guest/booking.php">Book a Room</a></li>
        <li><a href="<?php echo $base_path; ?>index.php#how-it-works">How it Works</a></li>
      </ul>
    </div>

    <!-- Account links -->
    <div class="footer__links">
      <h6>Account</h6>
      <ul>
        <li><a href="<?php echo $base_path; ?>pages/guest/login.php">Guest Login</a></li>
        <li><a href="<?php echo $base_path; ?>pages/guest/register.php">Register</a></li>
        <li><a href="<?php echo $base_path; ?>pages/admin/login.php">Staff Portal</a></li>
      </ul>
    </div>

    <!-- Contact -->
    <div class="footer__links">
      <h6>Contact</h6>
      <ul>
        <li><a href="mailto:info@windlandhotel.rw">info@windlandhotel.rw</a></li>
        <li><a href="tel:+250780000000">+250 780 000 000</a></li>
        <li><span style="color:rgba(253,252,248,0.4);font-size:0.82rem;">Kigali, Rwanda</span></li>
      </ul>
    </div>

  </div><!-- /.footer__inner -->

  <div class="footer__bottom">
    <p>&copy; <?php echo date('Y'); ?> Wind Land Hotel. All rights reserved.</p>
    <div class="footer__badge">
      <span>SYSTEMS ONLINE</span>
    </div>
  </div>

</footer><!-- /.footer -->

<!-- Global JavaScript -->
<script src="<?php echo $base_path; ?>assets/js/main.js"></script>
</body>
</html>
