<?php
/**
 * Wind Land Hotel — Admin Authentication Guard
 * Checks for a valid admin session, enforces a 30-minute idle timeout,
 * and verifies the account is still active on every page load.
 * Redirects to the staff login page if the session is absent, expired,
 * or the account has been deactivated.
 */

require_once __DIR__ . '/../config/config.php';

// ── Session timeout check ──────────────────────────────
if (isset($_SESSION['admin_id'])) {
    $idle = time() - ($_SESSION['admin_last_activity'] ?? time());

    if ($idle > SESSION_TIMEOUT) {
        session_unset();
        session_destroy();
        session_start();
        $_SESSION['timeout_msg'] = 'Your session expired after 30 minutes of inactivity. Please log in again.';
        header('Location: ' . BASE_URL . '/pages/admin/login.php');
        exit;
    }

    $_SESSION['admin_last_activity'] = time();
}

// ── Authentication check ───────────────────────────────
if (!isset($_SESSION['admin_id'])) {
    header('Location: ' . BASE_URL . '/pages/admin/login.php');
    exit;
}

// ── Active account check (runs on every protected page load) ──
// Re-verify from DB so deactivating a staff mid-session takes effect immediately.
require_once __DIR__ . '/../config/Database.php';

$__db   = Database::getInstance()->getConnection();
$__stmt = $__db->prepare(
    "SELECT is_active FROM admins WHERE id = ? LIMIT 1"
);

if ($__stmt) {
    $__aid = (int)$_SESSION['admin_id'];
    $__stmt->bind_param('i', $__aid);
    $__stmt->execute();
    $__row = $__stmt->get_result()->fetch_assoc();
    $__stmt->close();

    if (!$__row || (int)$__row['is_active'] === 0) {
        // Account was deactivated — destroy session and redirect
        session_unset();
        session_destroy();
        session_start();
        $_SESSION['timeout_msg'] = 'Your account has been deactivated. Please contact the Super Admin.';
        header('Location: ' . BASE_URL . '/pages/admin/login.php');
        exit;
    }
}

// Expose the admin's role to the including page
$admin_role = $_SESSION['admin_role'] ?? null;
