<?php if (!defined('STAFF_LAYOUT')) die('Direct access not permitted.'); ?>
  </div><!-- /.admin-content -->
</div><!-- /.admin-layout -->

<script src="../../assets/js/main.js"></script>
<script>
// Live clock
function updateClock() {
  const el = document.getElementById('clock');
  if (el) el.textContent = new Date().toLocaleTimeString();
}
setInterval(updateClock, 1000);
updateClock();

// Auto-hide flash alerts after 4 seconds
setTimeout(() => {
  document.querySelectorAll('.alert').forEach(a => {
    a.style.transition = 'opacity 0.5s';
    a.style.opacity = '0';
    setTimeout(() => a.style.display = 'none', 500);
  });
}, 4000);

// Auto-refresh every 30 seconds
setTimeout(() => location.reload(), 30000);

// Mobile sidebar toggle
const sidebarToggle  = document.getElementById('sidebar-toggle');
const sidebar        = document.querySelector('.admin-sidebar');
const sidebarOverlay = document.getElementById('sidebar-overlay');

function openSidebar() {
  sidebar.classList.add('open');
  sidebarOverlay.style.display = 'block';
  document.body.style.overflow = 'hidden';
  sidebarToggle.setAttribute('aria-expanded', 'true');
}
function closeSidebar() {
  sidebar.classList.remove('open');
  sidebarOverlay.style.display = 'none';
  document.body.style.overflow = '';
  sidebarToggle.setAttribute('aria-expanded', 'false');
}
sidebarToggle?.addEventListener('click', () => {
  sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
});
sidebarOverlay?.addEventListener('click', closeSidebar);
document.querySelectorAll('.admin-nav__link').forEach(link => {
  link.addEventListener('click', () => { if (window.innerWidth <= 768) closeSidebar(); });
});
window.addEventListener('resize', () => { if (window.innerWidth > 768) closeSidebar(); });
</script>
</body>
</html>
