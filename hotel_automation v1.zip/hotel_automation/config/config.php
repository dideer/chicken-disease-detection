<?php
/**
 * Wind Land Hotel — Application Configuration
 * Global constants, session bootstrap, and error reporting.
 */

// ── Error Reporting (development) ─────────────────────
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ── Database ───────────────────────────────────────────
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'hotel_automation');

// ── Application ────────────────────────────────────────
define('BASE_URL', 'http://localhost/wwww/hotel_automation');

// ── Automation Thresholds ──────────────────────────────
define('TEMP_THRESHOLD', 28);   // °C — AC triggers above this value

// ── Session Timeout ────────────────────────────────────
define('SESSION_TIMEOUT', 1800);  // 30 minutes in seconds

// ── Session Bootstrap ──────────────────────────────────
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
