<?php
/**
 * Wind Land Hotel — Database Class
 * Singleton MySQLi connection wrapper.
 */

require_once __DIR__ . '/config.php';

class Database
{
    /** @var Database|null Holds the single class instance */
    private static ?Database $instance = null;

    /** @var mysqli The active MySQLi connection */
    private mysqli $connection;

    /**
     * Private constructor — prevents direct instantiation.
     * Connects to MySQL using constants defined in config.php.
     */
    private function __construct()
    {
        $this->connection = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

        if ($this->connection->connect_error) {
            die('Database connection failed: ' . $this->connection->connect_error);
        }

        // Enforce UTF-8 for all queries
        $this->connection->set_charset('utf8mb4');
    }

    /**
     * Returns the single instance of this class.
     * Creates it on the first call; reuses it on every subsequent call.
     *
     * @return Database
     */
    public static function getInstance(): Database
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Returns the underlying MySQLi connection object.
     *
     * @return mysqli
     */
    public function getConnection(): mysqli
    {
        return $this->connection;
    }

    /** Block cloning to enforce singleton */
    private function __clone() {}

    /** Block unserialization to enforce singleton */
    public function __wakeup() {}
}
