/**
 * Wind Land Hotel — Main JavaScript
 * Handles: navigation, forms, toggles, smooth scroll, sensor refresh
 */

/* ── Utility ─────────────────────────────────────────── */
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

/* ── Navigation ──────────────────────────────────────── */
function initNav() {
  const nav       = $('.nav');
  const hamburger = $('.nav__hamburger');
  const mobileNav = $('.nav__mobile');

  if (!nav) return;

  // Scroll state
  const onScroll = () => {
    nav.classList.toggle('scrolled', window.scrollY > 20);
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  // Hamburger toggle
  if (hamburger && mobileNav) {
    hamburger.addEventListener('click', () => {
      const open = hamburger.classList.toggle('open');
      mobileNav.classList.toggle('open', open);
      document.body.style.overflow = open ? 'hidden' : '';
    });
  }

  // Close mobile nav on link click
  $$('.nav__mobile .nav__link').forEach(link => {
    link.addEventListener('click', () => {
      hamburger && hamburger.classList.remove('open');
      mobileNav && mobileNav.classList.remove('open');
      document.body.style.overflow = '';
    });
  });

  // Active link highlighting
  const currentPath = window.location.pathname.split('/').pop();
  $$('.nav__link').forEach(link => {
    const href = link.getAttribute('href')?.split('/').pop();
    if (href && currentPath && href === currentPath) {
      link.classList.add('active');
    }
  });
}

/* ── Smooth Scroll ───────────────────────────────────── */
function initSmoothScroll() {
  document.addEventListener('click', e => {
    const a = e.target.closest('a[href^="#"]');
    if (!a) return;
    const target = document.getElementById(a.getAttribute('href').slice(1));
    if (!target) return;
    e.preventDefault();
    const offset = 80;
    window.scrollTo({ top: target.offsetTop - offset, behavior: 'smooth' });
  });
}

/* ── Password Toggle ─────────────────────────────────── */
function initPasswordToggles() {
  $$('.toggle-pw').forEach(btn => {
    btn.addEventListener('click', () => {
      const wrap  = btn.closest('.input-wrap');
      const input = wrap?.querySelector('input');
      if (!input) return;
      const isText = input.type === 'text';
      input.type = isText ? 'password' : 'text';
      btn.innerHTML = isText ? eyeIcon() : eyeOffIcon();
      btn.setAttribute('aria-label', isText ? 'Show password' : 'Hide password');
    });
  });
}

function eyeIcon() {
  return `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`;
}
function eyeOffIcon() {
  return `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>`;
}

/* ── Form Validation ─────────────────────────────────── */
function initFormValidation() {
  // Registration form
  const regForm = $('#register-form');
  if (regForm) initRegisterValidation(regForm);

  // Login forms
  $$('.login-form').forEach(f => initLoginValidation(f));

  // Booking form
  const bookForm = $('#booking-form');
  if (bookForm) initBookingForm(bookForm);
}

function showError(input, msg) {
  input.classList.add('error');
  input.classList.remove('success');
  const err = input.closest('.form-group')?.querySelector('.form-error');
  if (err) { err.textContent = msg; err.classList.add('show'); }
}
function showSuccess(input) {
  input.classList.remove('error');
  input.classList.add('success');
  const err = input.closest('.form-group')?.querySelector('.form-error');
  if (err) err.classList.remove('show');
}
function clearState(input) {
  input.classList.remove('error','success');
  const err = input.closest('.form-group')?.querySelector('.form-error');
  if (err) err.classList.remove('show');
}

function validateEmail(v) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); }
function validatePhone(v) { return /^\+?[\d\s\-()]{8,15}$/.test(v); }

function initRegisterValidation(form) {
  const fields = {
    full_name:        form.querySelector('#full_name'),
    email:            form.querySelector('#email'),
    phone:            form.querySelector('#phone'),
    password:         form.querySelector('#password'),
    confirm_password: form.querySelector('#confirm_password'),
  };

  // Live validation
  Object.values(fields).forEach(f => {
    if (!f) return;
    f.addEventListener('blur', () => validateRegField(f, fields));
    f.addEventListener('input', () => clearState(f));
  });

  form.addEventListener('submit', e => {
    let valid = true;
    Object.values(fields).forEach(f => {
      if (f && !validateRegField(f, fields)) valid = false;
    });
    if (!valid) e.preventDefault();
  });
}

function validateRegField(f, fields) {
  const v = f.value.trim();
  if (f.id === 'full_name') {
    if (!v) { showError(f, 'Full name is required'); return false; }
    if (v.length < 3) { showError(f, 'Name must be at least 3 characters'); return false; }
  }
  if (f.id === 'email') {
    if (!v) { showError(f, 'Email is required'); return false; }
    if (!validateEmail(v)) { showError(f, 'Enter a valid email address'); return false; }
  }
  if (f.id === 'phone') {
    if (!v) { showError(f, 'Phone number is required'); return false; }
    if (!validatePhone(v)) { showError(f, 'Enter a valid phone number'); return false; }
  }
  if (f.id === 'password') {
    if (!v) { showError(f, 'Password is required'); return false; }
    if (v.length < 8) { showError(f, 'Password must be at least 8 characters'); return false; }
  }
  if (f.id === 'confirm_password') {
    const pw = fields.password?.value;
    if (!v) { showError(f, 'Please confirm your password'); return false; }
    if (v !== pw) { showError(f, 'Passwords do not match'); return false; }
  }
  showSuccess(f);
  return true;
}

function initLoginValidation(form) {
  const email = form.querySelector('#email');
  const pw    = form.querySelector('#password');

  form.addEventListener('submit', e => {
    let ok = true;
    if (email && !email.value.trim()) { showError(email, 'Email is required'); ok = false; }
    else if (email && !validateEmail(email.value.trim())) { showError(email, 'Invalid email'); ok = false; }
    if (pw && !pw.value.trim()) { showError(pw, 'Password is required'); ok = false; }
    if (!ok) e.preventDefault();
  });
}

/* ── Booking Form — price calculator ────────────────── */
function initBookingForm(form) {
  const checkIn  = form.querySelector('#check_in');
  const checkOut = form.querySelector('#check_out');
  const totalEl  = document.getElementById('total-price');
  const nightsEl = document.getElementById('total-nights');
  const pricePerNight = parseFloat(form.dataset.price || 0);

  function calcTotal() {
    if (!checkIn?.value || !checkOut?.value) return;
    const d1 = new Date(checkIn.value);
    const d2 = new Date(checkOut.value);
    const nights = Math.ceil((d2 - d1) / (1000 * 60 * 60 * 24));
    if (nights < 1) {
      showError(checkOut, 'Check-out must be after check-in');
      return;
    }
    clearState(checkOut);
    const total = nights * pricePerNight;
    if (nightsEl) nightsEl.textContent = nights + (nights === 1 ? ' night' : ' nights');
    if (totalEl)  totalEl.textContent  = '$' + total.toLocaleString();
  }

  checkIn?.addEventListener('change', () => {
    // Check-out min = check-in + 1
    if (checkIn.value) {
      const next = new Date(checkIn.value);
      next.setDate(next.getDate() + 1);
      if (checkOut) checkOut.min = next.toISOString().split('T')[0];
    }
    calcTotal();
  });
  checkOut?.addEventListener('change', calcTotal);

  // Set today as check-in min
  const today = new Date().toISOString().split('T')[0];
  if (checkIn) checkIn.min = today;

  form.addEventListener('submit', e => {
    if (!checkIn?.value) { showError(checkIn, 'Check-in date required'); e.preventDefault(); return; }
    if (!checkOut?.value) { showError(checkOut, 'Check-out date required'); e.preventDefault(); return; }
    const d1 = new Date(checkIn.value);
    const d2 = new Date(checkOut.value);
    if (d2 <= d1) { showError(checkOut, 'Check-out must be after check-in'); e.preventDefault(); }
  });
}

/* ── Toggle Switches ─────────────────────────────────── */
function initToggles() {
  $$('.toggle-wrap').forEach(wrap => {
    const cb = wrap.querySelector('input[type="checkbox"]');
    if (!cb) return;

    const syncState = () => wrap.classList.toggle('active', cb.checked);
    syncState();

    wrap.addEventListener('click', e => {
      if (e.target === cb) { syncState(); return; }
      cb.checked = !cb.checked;
      syncState();
      cb.dispatchEvent(new Event('change', { bubbles: true }));
    });
  });
}

/* ── Room filter (rooms listing page) ───────────────── */
function initRoomFilter() {
  const filterBtns = $$('.filter-btn');
  const roomCards  = $$('.room-card[data-type]');
  if (!filterBtns.length) return;

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const type = btn.dataset.filter;
      roomCards.forEach(card => {
        const show = type === 'all' || card.dataset.type === type;
        card.style.display = show ? '' : 'none';
        if (show) card.classList.add('fade-in');
      });
    });
  });
}

/* ── Guest search (admin guests page) ───────────────── */
function initGuestSearch() {
  const input = $('#guest-search');
  if (!input) return;
  const rows = $$('#guests-table tbody tr');

  input.addEventListener('input', () => {
    const q = input.value.toLowerCase();
    rows.forEach(row => {
      const text = row.textContent.toLowerCase();
      row.style.display = text.includes(q) ? '' : 'none';
    });
  });
}

/* ── Sensor Auto-Refresh ─────────────────────────────── */
function initSensorRefresh() {
  const panel = $('#sensor-panel');
  if (!panel) return;

  function refresh() {
    fetch('sensor_data.php?ajax=1')
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        if (!data) return;
        const tempEl = document.getElementById('sensor-temp');
        const humEl  = document.getElementById('sensor-humidity');
        const lightEl = document.getElementById('sensor-light');
        const acEl   = document.getElementById('sensor-ac');
        if (tempEl)  tempEl.textContent  = data.temperature ?? '--';
        if (humEl)   humEl.textContent   = data.humidity ?? '--';
        if (lightEl) lightEl.textContent = data.lighting ?? '--';
        if (acEl)    acEl.textContent    = data.ac_fan ?? '--';
      })
      .catch(() => {}); // silent fail
  }

  setInterval(refresh, 10000);
}

/* ── Admin Dashboard Auto-Refresh ───────────────────── */
function initDashboardRefresh() {
  const table = $('#rooms-dashboard-table');
  if (!table) return;

  setInterval(() => {
    fetch('dashboard_data.php?ajax=1')
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        if (!data) return;
        // Update stat cards
        ['total','occupied','available','alerts'].forEach(key => {
          const el = document.getElementById('stat-' + key);
          if (el && data[key] !== undefined) el.textContent = data[key];
        });
      })
      .catch(() => {});
  }, 10000);
}

/* ── Admin room status dropdown ─────────────────────── */
function initRoomStatusChange() {
  $$('.room-status-select').forEach(sel => {
    sel.addEventListener('change', () => {
      const roomId = sel.dataset.room;
      const status = sel.value;
      const badge  = sel.closest('tr')?.querySelector('.status-badge');

      fetch('update_room.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `room_id=${encodeURIComponent(roomId)}&status=${encodeURIComponent(status)}`
      })
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        if (data?.success && badge) {
          badge.textContent = status.charAt(0).toUpperCase() + status.slice(1);
          badge.className = 'badge';
          if (status === 'available')   badge.classList.add('badge--green');
          else if (status === 'occupied') badge.classList.add('badge--red');
          else badge.classList.add('badge--gold');
        }
      })
      .catch(() => {});
    });
  });
}

/* ── Init all ────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  initNav();
  initSmoothScroll();
  initPasswordToggles();
  initFormValidation();
  initToggles();
  initRoomFilter();
  initGuestSearch();
  initSensorRefresh();
  initDashboardRefresh();
  initRoomStatusChange();
});
